#!/bin/bash
set -e  # Exit on error

# Configuration
MYSQL_USER="root"
MYSQL_HOST="localhost"
MYSQL_PASS="guheUIGei3883hTIHuie74829GhuieG784ui"
APACHE_CONF="/etc/apache2/sites-available/000-default.conf"
WEB_ROOT="/var/www/html"
SQL_TEST="${WEB_ROOT}/test.sql"

# Update system
echo "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install required packages
echo "Installing required packages..."
sudo apt install -y apache2 unzip net-tools mysql-server

# Add PHP repository and install PHP packages
echo "Setting up PHP..."
sudo add-apt-repository -y ppa:ondrej/php
sudo apt update
sudo apt install -y php8.1 php8.1-mbstring libapache2-mod-php8.1 php8.1-mysql

# Configure Apache
echo "Configuring Apache..."
apache_config=$(cat <<'EOF'
<Directory /var/www/html>
    Options Indexes FollowSymLinks
    AllowOverride All
    Require all granted
</Directory>
EOF
)

echo "$apache_config" | sudo tee -a "$APACHE_CONF" > /dev/null
sudo a2enmod rewrite

# Configure MySQL
echo "Configuring MySQL..."
sudo mysql -u "$MYSQL_USER" -h "$MYSQL_HOST" <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$MYSQL_PASS';
CREATE DATABASE IF NOT EXISTS coinbase;
FLUSH PRIVILEGES;
EOF

# Set up web application
echo "Setting up web application..."
if [ -f "${WEB_ROOT}/index.html" ]; then
    sudo rm "${WEB_ROOT}/index.html"
fi

if [ -f "CB_1.8.zip" ]; then
    sudo mv CB_1.8.zip "$WEB_ROOT/"
    cd "$WEB_ROOT"
    sudo unzip -o CB_1.8.zip
    sudo rm CB_1.8.zip
else
    echo "Error: CB_1.8.zip not found!"
    exit 1
fi

# Import database
echo "Importing database..."
if [ -f "$SQL_TEST" ]; then
    mysql -u "$MYSQL_USER" -p"$MYSQL_PASS" -h "$MYSQL_HOST" coinbase < "$SQL_TEST"
else
    echo "Error: test.sql not found!"
    exit 1
fi

# Restart Apache
echo "Restarting Apache..."
sudo service apache2 restart

echo "Installation completed successfully!"